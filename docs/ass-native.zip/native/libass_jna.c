#include <ass/ass.h>
#include <stdint.h>
#include <stdlib.h>
#include <string.h>

#ifdef _WIN32
#define LA_EXPORT __declspec(dllexport)
#else
#define LA_EXPORT __attribute__((visibility("default")))
#endif

typedef struct {
	ASS_Library *library;
	ASS_Renderer *renderer;
	ASS_Track *track;
	int width;
	int height;
} la_renderer;

LA_EXPORT void *la_create(int width, int height) {
	if (width <= 0 || height <= 0) return NULL;
	la_renderer *r = (la_renderer *)calloc(1, sizeof(*r));
	if (!r) return NULL;
	r->width = width;
	r->height = height;
	r->library = ass_library_init();
	r->renderer = r->library ? ass_renderer_init(r->library) : NULL;
	if (!r->renderer) {
		if (r->library) ass_library_done(r->library);
		free(r);
		return NULL;
	}
	ass_set_frame_size(r->renderer, width, height);
	ass_set_storage_size(r->renderer, width, height);
	ass_set_fonts(r->renderer, NULL, "Sans", 1, NULL, 1);
	return r;
}

LA_EXPORT void la_destroy(void *handle) {
	la_renderer *r = (la_renderer *)handle;
	if (!r) return;
	if (r->track) ass_free_track(r->track);
	if (r->renderer) ass_renderer_done(r->renderer);
	if (r->library) ass_library_done(r->library);
	free(r);
}

LA_EXPORT int la_load_track(void *handle, const uint8_t *data, int length) {
	la_renderer *r = (la_renderer *)handle;
	if (!r || !data || length <= 0) return -1;
	ASS_Track *track = ass_read_memory(r->library, (unsigned char *)data, length, "UTF-8");
	if (!track) return -2;
	if (r->track) ass_free_track(r->track);
	r->track = track;
	return 0;
}

static void blend_pixel(uint8_t *dst, uint8_t red, uint8_t green, uint8_t blue, uint8_t alpha) {
	unsigned int source_alpha = alpha;
	unsigned int destination_alpha = dst[3];
	unsigned int inverse = 255 - source_alpha;
	unsigned int output_alpha = source_alpha + (destination_alpha * inverse + 127) / 255;
	if (!output_alpha) {
		dst[0] = dst[1] = dst[2] = dst[3] = 0;
		return;
	}
	dst[0] = (uint8_t)((red * source_alpha + dst[0] * destination_alpha * inverse / 255) / output_alpha);
	dst[1] = (uint8_t)((green * source_alpha + dst[1] * destination_alpha * inverse / 255) / output_alpha);
	dst[2] = (uint8_t)((blue * source_alpha + dst[2] * destination_alpha * inverse / 255) / output_alpha);
	dst[3] = (uint8_t)output_alpha;
}

LA_EXPORT int la_render_rgba(void *handle, int64_t timestamp_milliseconds,
							 uint8_t *destination, int capacity) {
	la_renderer *r = (la_renderer *)handle;
	int required = r ? r->width * r->height * 4 : 0;
	if (!r || !destination || capacity < required || !r->track) return -1;
	memset(destination, 0, (size_t)required);

	int changed = 0;
	ASS_Image *image = ass_render_frame(r->renderer, r->track,
										 (long long)timestamp_milliseconds, &changed);
	for (; image; image = image->next) {
	        uint8_t red = (uint8_t)((image->color >> 24) & 0xff);
                uint8_t green = (uint8_t)((image->color >> 16) & 0xff);
                uint8_t blue = (uint8_t)((image->color >> 8) & 0xff);
                int color_alpha = 255 - (image->color & 0xff);

		for (int y = 0; y < image->h; y++) {
			int target_y = image->dst_y + y;
			if (target_y < 0 || target_y >= r->height) continue;
			for (int x = 0; x < image->w; x++) {
				int target_x = image->dst_x + x;
				if (target_x < 0 || target_x >= r->width) continue;
				uint8_t coverage = image->bitmap[y * image->stride + x];
				uint8_t alpha = (uint8_t)((color_alpha * coverage + 127) / 255);
				blend_pixel(destination + ((target_y * r->width + target_x) * 4),
							red, green, blue, alpha);
			}
		}
	}
	return 0;
}
