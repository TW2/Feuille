public final class FmpFpsPlayer {
    private FmpFpsPlayer() {}

    public static void main(String[] args) {
        if (args.length < 1 || args.length > 2) {
            System.err.println(
                    "Usage: FmpFpsPlayer <media-file> [ASS/SSA-subtitle-file]");
            System.exit(2);
        }
        FmpSwingPlayer.main(args);
    }
}
