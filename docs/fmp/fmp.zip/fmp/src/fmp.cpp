#include "fmp/fmp.h"

extern "C" {
#include <ass/ass.h>
#include <libavcodec/avcodec.h>
#include <libavformat/avformat.h>
#include <libavutil/channel_layout.h>
#include <libavutil/error.h>
#include <libavutil/imgutils.h>
#include <libavutil/mathematics.h>
#include <libavutil/opt.h>
#include <libswresample/swresample.h>
#include <libswscale/swscale.h>
}

#include <algorithm>
#include <cmath>
#include <cstdlib>
#include <cstring>
#include <exception>
#include <atomic>
#include <chrono>
#include <condition_variable>
#include <deque>
#include <limits>
#include <memory>
#include <mutex>
#include <new>
#include <string>
#include <thread>
#include <vector>

namespace {

constexpr int kAudioOutputRate = 48000;
constexpr int kAudioOutputChannels = 2;
constexpr int kTelecineSampleFrameLimit = 120;
constexpr size_t kEventQueueLimit = 8;
constexpr auto kEventLookaheadTimeout = std::chrono::milliseconds(50);
thread_local std::string last_open_error;

std::string ffmpeg_error(int error_code) {
    char buffer[AV_ERROR_MAX_STRING_SIZE] = {};
    av_strerror(error_code, buffer, sizeof(buffer));
    return buffer;
}

struct OwnedEvent {
    FmpEvent event{};
    std::vector<uint8_t> bytes;
};

struct QueuedPacket {
    AVPacket *packet = nullptr;
    uint64_t generation = 0;
    bool flush = false;

    QueuedPacket() = default;
    QueuedPacket(const QueuedPacket &) = delete;
    QueuedPacket &operator=(const QueuedPacket &) = delete;
    QueuedPacket(QueuedPacket &&other) noexcept
        : packet(other.packet), generation(other.generation), flush(other.flush) {
        other.packet = nullptr;
    }
    QueuedPacket &operator=(QueuedPacket &&other) noexcept {
        if (this != &other) {
            av_packet_free(&packet);
            packet = other.packet;
            generation = other.generation;
            flush = other.flush;
            other.packet = nullptr;
        }
        return *this;
    }
    ~QueuedPacket() {
        av_packet_free(&packet);
    }
};

struct PacketQueue {
    std::mutex mutex;
    std::condition_variable changed;
    std::deque<QueuedPacket> packets;
    bool input_finished = false;
};

} // namespace

struct FmpPlayer {
    enum class PlaybackState {
        Playing,
        Paused,
        Stopped
    };

    AVFormatContext *format = nullptr;
    AVCodecContext *video_decoder = nullptr;
    AVCodecContext *audio_decoder = nullptr;
    SwsContext *scaler = nullptr;
    SwrContext *resampler = nullptr;
    AVPacket *packet = nullptr;
    AVFrame *video_frame = nullptr;
    AVFrame *audio_frame = nullptr;
    ASS_Library *ass_library = nullptr;
    ASS_Renderer *ass_renderer = nullptr;
    ASS_Track *ass_track = nullptr;
    int video_stream = -1;
    int audio_stream = -1;
    int subtitle_stream = -1;
    int sampled_video_frames = 0;
    int sampled_repeat_frames = 0;
    int64_t last_audio_end_pts_us = 0;
    std::atomic<PlaybackState> playback_state{PlaybackState::Playing};
    std::atomic<bool> shutting_down{false};
    std::atomic<bool> transitioning{false};
    std::atomic<uint64_t> generation{0};
    bool demux_finished = false;
    bool demux_started = false;
    bool demux_packet_pending = false;
    bool demux_eof_seen = false;
    bool playback_range_enabled = false;
    int64_t playback_range_start_us = 0;
    int64_t playback_range_end_us = 0;
    bool force_event_delivery = false;
    bool waiting_for_stream_event = false;
    std::chrono::steady_clock::time_point stream_event_wait_started;
    bool video_flush_queued = false;
    bool audio_flush_queued = false;
    bool subtitle_flush_queued = false;
    bool video_done = false;
    bool audio_done = false;
    bool subtitle_done = false;
    std::atomic<bool> subtitle_busy{false};
    PacketQueue video_packets;
    PacketQueue audio_packets;
    PacketQueue subtitle_packets;
    std::mutex control_mutex;
    std::condition_variable control_changed;
    std::mutex event_mutex;
    std::condition_variable event_changed;
    std::deque<OwnedEvent> video_events;
    std::deque<OwnedEvent> audio_events;
    std::mutex error_mutex;
    std::mutex subtitle_mutex;
    std::mutex video_decoder_mutex;
    std::mutex audio_decoder_mutex;
    std::string external_subtitle_path;
    std::thread video_thread;
    std::thread audio_thread;
    std::thread subtitle_thread;
    OwnedEvent current;
    std::string error;

    ~FmpPlayer() {
        shutting_down.store(true);
        control_changed.notify_all();
        video_packets.changed.notify_all();
        audio_packets.changed.notify_all();
        subtitle_packets.changed.notify_all();
        event_changed.notify_all();
        if (video_thread.joinable()) video_thread.join();
        if (audio_thread.joinable()) audio_thread.join();
        if (subtitle_thread.joinable()) subtitle_thread.join();
        if (format) {
            avformat_close_input(&format);
        }
        avcodec_free_context(&video_decoder);
        avcodec_free_context(&audio_decoder);
        sws_freeContext(scaler);
        swr_free(&resampler);
        av_packet_free(&packet);
        av_frame_free(&video_frame);
        av_frame_free(&audio_frame);
        if (ass_track) {
            ass_free_track(ass_track);
        }
        if (ass_renderer) {
            ass_renderer_done(ass_renderer);
        }
        if (ass_library) {
            ass_library_done(ass_library);
        }
    }
};

namespace {

int fail(FmpPlayer *player, const std::string &message) {
    last_open_error = message;
    if (player) {
        std::lock_guard<std::mutex> lock(player->error_mutex);
        player->error = message;
        player->event_changed.notify_all();
    }
    return -1;
}

int fail_ffmpeg(FmpPlayer *player, const char *operation, int error_code) {
    return fail(player, std::string(operation) + ": " + ffmpeg_error(error_code));
}

AVCodecContext *open_decoder(AVFormatContext *format, int stream_index,
                             std::string &error) {
    if (stream_index < 0) {
        return nullptr;
    }
    AVStream *stream = format->streams[stream_index];
    const AVCodec *codec = avcodec_find_decoder(stream->codecpar->codec_id);
    if (!codec) {
        error = "No decoder available for stream";
        return nullptr;
    }
    AVCodecContext *decoder = avcodec_alloc_context3(codec);
    if (!decoder) {
        error = "Unable to allocate decoder context";
        return nullptr;
    }
    int result = avcodec_parameters_to_context(decoder, stream->codecpar);
    if (result >= 0) {
        result = avcodec_open2(decoder, codec, nullptr);
    }
    if (result < 0) {
        error = "Unable to open decoder: " + ffmpeg_error(result);
        avcodec_free_context(&decoder);
        return nullptr;
    }
    return decoder;
}

int64_t timestamp_us(int64_t timestamp, AVRational time_base) {
    if (timestamp == AV_NOPTS_VALUE) {
        return 0;
    }
    return av_rescale_q(timestamp, time_base, AVRational{1, 1000000});
}

int receive_sampled_video_frames(FmpPlayer *player, int &frame_count,
                                int &repeat_count) {
    for (;;) {
        const int result = avcodec_receive_frame(player->video_decoder, player->video_frame);
        if (result == AVERROR(EAGAIN) || result == AVERROR_EOF) {
            return 0;
        }
        if (result < 0) {
            return result;
        }
        ++frame_count;
        if (player->video_frame->repeat_pict > 0) {
            ++repeat_count;
        }
        av_frame_unref(player->video_frame);
        if (frame_count >= kTelecineSampleFrameLimit) {
            return 0;
        }
    }
}

bool sample_telecine_cadence(FmpPlayer *player, int &frame_count,
                             int &repeat_count, std::string &error) {
    AVStream *stream = player->format->streams[player->video_stream];
    const int64_t start = stream->start_time == AV_NOPTS_VALUE
        ? 0 : stream->start_time;
    int result = av_seek_frame(player->format, player->video_stream, start,
                               AVSEEK_FLAG_BACKWARD);
    if (result < 0) {
        return false;
    }
    avcodec_flush_buffers(player->video_decoder);

    int decode_error = 0;
    while (frame_count < kTelecineSampleFrameLimit) {
        result = av_read_frame(player->format, player->packet);
        if (result < 0) {
            break;
        }
        if (player->packet->stream_index == player->video_stream) {
            result = avcodec_send_packet(player->video_decoder, player->packet);
            if (result == AVERROR(EAGAIN)) {
                decode_error = receive_sampled_video_frames(
                    player, frame_count, repeat_count);
                if (decode_error >= 0) {
                    result = avcodec_send_packet(player->video_decoder, player->packet);
                } else {
                    result = decode_error;
                }
            }
            if (result >= 0) {
                decode_error = receive_sampled_video_frames(
                    player, frame_count, repeat_count);
            } else {
                decode_error = result;
            }
        }
        av_packet_unref(player->packet);
        if (decode_error < 0 || frame_count >= kTelecineSampleFrameLimit) {
            break;
        }
    }
    av_packet_unref(player->packet);
    av_frame_unref(player->video_frame);

    result = av_seek_frame(player->format, player->video_stream, start,
                           AVSEEK_FLAG_BACKWARD);
    if (result < 0) {
        error = "Unable to rewind media after sampling video cadence: " +
                ffmpeg_error(result);
        return false;
    }
    avcodec_flush_buffers(player->video_decoder);
    if (player->audio_decoder) {
        avcodec_flush_buffers(player->audio_decoder);
    }
    return decode_error >= 0 && frame_count > 0;
}

void ensure_ass_track(FmpPlayer *player) {
    if (player->ass_track || !player->ass_library) {
        return;
    }
    player->ass_track = ass_new_track(player->ass_library);
    if (player->ass_track && player->subtitle_stream >= 0) {
        AVCodecParameters *parameters =
            player->format->streams[player->subtitle_stream]->codecpar;
        if (parameters->extradata && parameters->extradata_size > 0) {
            ass_process_codec_private(player->ass_track,
                                      reinterpret_cast<const char *>(parameters->extradata),
                                      parameters->extradata_size);
        }
    }
}

int initialize_audio_resampler(FmpPlayer *player) {
    AVChannelLayout output_layout = AV_CHANNEL_LAYOUT_STEREO;
    AVChannelLayout input_layout = player->audio_decoder->ch_layout;
    if (input_layout.nb_channels == 0) {
        av_channel_layout_default(&input_layout, kAudioOutputChannels);
    }
    const int result = swr_alloc_set_opts2(
        &player->resampler, &output_layout, AV_SAMPLE_FMT_S16, kAudioOutputRate,
        &input_layout, player->audio_decoder->sample_fmt,
        player->audio_decoder->sample_rate, 0, nullptr);
    if (input_layout.nb_channels != player->audio_decoder->ch_layout.nb_channels) {
        av_channel_layout_uninit(&input_layout);
    }
    if (result < 0) {
        return result;
    }
    return swr_init(player->resampler);
}

int blend_subtitles(FmpPlayer *player, OwnedEvent &event) {
    if (!player->ass_track || event.event.width <= 0 || event.event.height <= 0) {
        return 0;
    }
    ass_set_frame_size(player->ass_renderer, event.event.width, event.event.height);
    int changed = 0;
    ASS_Image *image = ass_render_frame(player->ass_renderer, player->ass_track,
                                        event.event.pts_us / 1000, &changed);
    const int width = event.event.width;
    const int height = event.event.height;
    for (; image; image = image->next) {
        const uint32_t color = image->color;
        const unsigned red = (color >> 24) & 0xff;
        const unsigned green = (color >> 16) & 0xff;
        const unsigned blue = (color >> 8) & 0xff;
        const unsigned base_alpha = 255 - (color & 0xff);
        for (int y = 0; y < image->h; ++y) {
            const int target_y = image->dst_y + y;
            if (target_y < 0 || target_y >= height) {
                continue;
            }
            for (int x = 0; x < image->w; ++x) {
                const int target_x = image->dst_x + x;
                if (target_x < 0 || target_x >= width) {
                    continue;
                }
                const unsigned coverage = image->bitmap[y * image->stride + x];
                const unsigned alpha = (coverage * base_alpha + 127) / 255;
                if (!alpha) {
                    continue;
                }
                uint8_t *pixel = event.bytes.data() +
                    static_cast<size_t>(target_y) * event.event.stride +
                    static_cast<size_t>(target_x) * 4;
                const unsigned inverse = 255 - alpha;
                const unsigned destination_alpha = pixel[3];
                const unsigned output_alpha =
                    alpha + (destination_alpha * inverse + 127) / 255;
                for (int channel = 0; channel < 3; ++channel) {
                    const unsigned source_color =
                        channel == 0 ? red : channel == 1 ? green : blue;
                    const unsigned premultiplied =
                        source_color * alpha +
                        (pixel[channel] * destination_alpha * inverse + 127) / 255;
                    pixel[channel] = static_cast<uint8_t>(
                        (premultiplied + output_alpha / 2) / output_alpha);
                }
                pixel[3] = static_cast<uint8_t>(output_alpha);
            }
        }
    }
    return 0;
}

void clear_error(FmpPlayer *player) {
    std::lock_guard<std::mutex> lock(player->error_mutex);
    player->error.clear();
}

int publish_event(FmpPlayer *player, OwnedEvent event, bool is_video,
                  uint64_t packet_generation) {
    std::unique_lock<std::mutex> lock(player->event_mutex);
    std::deque<OwnedEvent> &events = is_video
        ? player->video_events : player->audio_events;
    player->event_changed.wait(lock, [&] {
        return player->shutting_down.load() ||
               player->generation.load() != packet_generation ||
               events.size() < kEventQueueLimit;
    });
    if (player->shutting_down.load() ||
        player->generation.load() != packet_generation) {
        return 0;
    }
    events.push_back(std::move(event));
    lock.unlock();
    player->event_changed.notify_all();
    return 0;
}

int queue_video_frame(FmpPlayer *player, AVFrame *frame,
                      uint64_t packet_generation) {
    const int width = frame->width;
    const int height = frame->height;
    if (width <= 0 || height <= 0) {
        return fail(player, "Decoded video frame has invalid dimensions");
    }
    OwnedEvent event;
    event.event.type = FMP_EVENT_VIDEO;
    event.event.pts_us = timestamp_us(
        frame->best_effort_timestamp,
        player->format->streams[player->video_stream]->time_base);
    event.event.width = width;
    event.event.height = height;
    event.event.stride = width * 4;
    event.bytes.resize(static_cast<size_t>(event.event.stride) * height);

    player->scaler = sws_getCachedContext(
        player->scaler, width, height, static_cast<AVPixelFormat>(frame->format),
        width, height, AV_PIX_FMT_RGBA, SWS_BILINEAR, nullptr, nullptr, nullptr);
    if (!player->scaler) {
        return fail(player, "Unable to create video pixel converter");
    }
    uint8_t *destinations[4] = {event.bytes.data(), nullptr, nullptr, nullptr};
    int destination_strides[4] = {event.event.stride, 0, 0, 0};
    const int rows = sws_scale(player->scaler, frame->data, frame->linesize, 0,
                              height, destinations, destination_strides);
    if (rows != height) {
        return fail(player, "Unable to convert decoded video frame to RGBA");
    }
    {
        std::lock_guard<std::mutex> lock(player->subtitle_mutex);
        blend_subtitles(player, event);
    }
    return publish_event(player, std::move(event), true, packet_generation);
}

int queue_audio_frame(FmpPlayer *player, AVFrame *frame,
                      uint64_t packet_generation) {
    if (!player->resampler) {
        const int result = initialize_audio_resampler(player);
        if (result < 0) {
            return fail_ffmpeg(player, "Unable to initialize audio resampler", result);
        }
    }
    const int64_t delay = swr_get_delay(player->resampler, frame->sample_rate);
    const int output_capacity = static_cast<int>(av_rescale_rnd(
        delay + frame->nb_samples, kAudioOutputRate, frame->sample_rate,
        AV_ROUND_UP));
    OwnedEvent event;
    event.event.type = FMP_EVENT_AUDIO;
    event.event.pts_us = timestamp_us(
        frame->best_effort_timestamp,
        player->format->streams[player->audio_stream]->time_base);
    event.event.sample_rate = kAudioOutputRate;
    event.event.channels = kAudioOutputChannels;
    event.event.duration_us = av_rescale(frame->nb_samples, 1000000,
                                         frame->sample_rate);
    event.bytes.resize(static_cast<size_t>(output_capacity) *
                       kAudioOutputChannels * sizeof(int16_t));
    uint8_t *output[1] = {event.bytes.data()};
    const int samples = swr_convert(player->resampler, output, output_capacity,
                                    const_cast<const uint8_t **>(frame->extended_data),
                                    frame->nb_samples);
    if (samples < 0) {
        return fail_ffmpeg(player, "Unable to convert decoded audio frame", samples);
    }
    event.bytes.resize(static_cast<size_t>(samples) *
                       kAudioOutputChannels * sizeof(int16_t));
    event.event.duration_us = av_rescale(samples, 1000000, kAudioOutputRate);
    player->last_audio_end_pts_us = event.event.pts_us + event.event.duration_us;
    return publish_event(player, std::move(event), false, packet_generation);
}

int flush_audio_resampler(FmpPlayer *player, uint64_t packet_generation) {
    if (!player->resampler || !player->audio_decoder) {
        return 0;
    }
    const int64_t delay = swr_get_delay(player->resampler,
                                        player->audio_decoder->sample_rate);
    const int output_capacity = static_cast<int>(av_rescale_rnd(
        delay, kAudioOutputRate, player->audio_decoder->sample_rate, AV_ROUND_UP));
    if (output_capacity <= 0) {
        return 0;
    }
    OwnedEvent event;
    event.event.type = FMP_EVENT_AUDIO;
    event.event.pts_us = player->last_audio_end_pts_us;
    event.event.sample_rate = kAudioOutputRate;
    event.event.channels = kAudioOutputChannels;
    event.bytes.resize(static_cast<size_t>(output_capacity) *
                       kAudioOutputChannels * sizeof(int16_t));
    uint8_t *output[1] = {event.bytes.data()};
    const int samples = swr_convert(player->resampler, output, output_capacity,
                                    nullptr, 0);
    if (samples < 0) {
        return fail_ffmpeg(player, "Unable to flush audio resampler", samples);
    }
    if (samples == 0) {
        return 0;
    }
    event.bytes.resize(static_cast<size_t>(samples) *
                       kAudioOutputChannels * sizeof(int16_t));
    event.event.duration_us = av_rescale(samples, 1000000, kAudioOutputRate);
    player->last_audio_end_pts_us += event.event.duration_us;
    return publish_event(player, std::move(event), false, packet_generation);
}

int receive_worker_frames(FmpPlayer *player, bool is_video,
                          uint64_t packet_generation) {
    AVCodecContext *decoder = is_video
        ? player->video_decoder : player->audio_decoder;
    AVFrame *frame = is_video ? player->video_frame : player->audio_frame;
    for (;;) {
        const int result = avcodec_receive_frame(decoder, frame);
        if (result == AVERROR(EAGAIN) || result == AVERROR_EOF) {
            return 0;
        }
        if (result < 0) {
            return fail_ffmpeg(player, "Unable to decode media frame", result);
        }
        const int queued = is_video
            ? queue_video_frame(player, frame, packet_generation)
            : queue_audio_frame(player, frame, packet_generation);
        av_frame_unref(frame);
        if (queued < 0) {
            return queued;
        }
    }
}

int decode_stream_packet(FmpPlayer *player, const QueuedPacket &item,
                         bool is_video) {
    AVCodecContext *decoder = is_video
        ? player->video_decoder : player->audio_decoder;
    std::mutex &decoder_mutex = is_video
        ? player->video_decoder_mutex : player->audio_decoder_mutex;
    std::lock_guard<std::mutex> decoder_lock(decoder_mutex);
    if (item.generation != player->generation.load()) {
        return 0;
    }
    int result = avcodec_send_packet(decoder, item.packet);
    if (result == AVERROR(EAGAIN)) {
        const int received = receive_worker_frames(
            player, is_video, item.generation);
        if (received < 0) {
            return received;
        }
        result = avcodec_send_packet(decoder, item.packet);
    }
    if (result < 0) {
        return fail_ffmpeg(player, "Unable to submit packet to decoder", result);
    }
    return receive_worker_frames(player, is_video, item.generation);
}

int flush_stream_decoder(FmpPlayer *player, bool is_video,
                         uint64_t packet_generation) {
    AVCodecContext *decoder = is_video
        ? player->video_decoder : player->audio_decoder;
    std::mutex &decoder_mutex = is_video
        ? player->video_decoder_mutex : player->audio_decoder_mutex;
    std::lock_guard<std::mutex> decoder_lock(decoder_mutex);
    int result = avcodec_send_packet(decoder, nullptr);
    if (result < 0 && result != AVERROR_EOF) {
        return fail_ffmpeg(player, "Unable to flush decoder", result);
    }
    result = receive_worker_frames(player, is_video, packet_generation);
    if (result < 0) {
        return result;
    }
    if (!is_video) {
        return flush_audio_resampler(player, packet_generation);
    }
    return 0;
}

bool wait_until_playing(FmpPlayer *player) {
    std::unique_lock<std::mutex> lock(player->control_mutex);
    player->control_changed.wait(lock, [&] {
        return player->shutting_down.load() ||
               (!player->transitioning.load() &&
                player->playback_state.load() == FmpPlayer::PlaybackState::Playing);
    });
    return !player->shutting_down.load();
}

void mark_stream_done(FmpPlayer *player, bool is_video) {
    {
        std::lock_guard<std::mutex> lock(player->event_mutex);
        (is_video ? player->video_done : player->audio_done) = true;
    }
    player->event_changed.notify_all();
}

void stream_worker(FmpPlayer *player, bool is_video) {
    PacketQueue &queue = is_video ? player->video_packets : player->audio_packets;
    try {
        for (;;) {
            if (!wait_until_playing(player)) {
                return;
            }
            QueuedPacket item;
            {
                std::unique_lock<std::mutex> lock(queue.mutex);
                queue.changed.wait(lock, [&] {
                    return player->shutting_down.load() ||
                           player->transitioning.load() ||
                           player->playback_state.load() !=
                               FmpPlayer::PlaybackState::Playing ||
                           !queue.packets.empty();
                });
                if (player->shutting_down.load()) {
                    return;
                }
                if (player->transitioning.load() ||
                    player->playback_state.load() !=
                        FmpPlayer::PlaybackState::Playing) {
                    continue;
                }
                if (queue.packets.empty()) {
                    continue;
                }
                item = std::move(queue.packets.front());
                queue.packets.pop_front();
            }
            queue.changed.notify_all();
            if (item.generation != player->generation.load()) {
                continue;
            }
            const int result = item.flush
                ? flush_stream_decoder(player, is_video, item.generation)
                : decode_stream_packet(player, item, is_video);
            if (result < 0) {
                continue;
            }
            if (item.flush && item.generation == player->generation.load()) {
                mark_stream_done(player, is_video);
            }
        }
    } catch (const std::bad_alloc &) {
        fail(player, "Out of memory in media decoding worker");
    } catch (const std::exception &exception) {
        fail(player, std::string("Media decoding worker failed: ") + exception.what());
    }
}

int add_subtitle_packet(FmpPlayer *player, const QueuedPacket &item) {
    if (!item.packet || item.generation != player->generation.load()) {
        return 0;
    }
    std::lock_guard<std::mutex> lock(player->subtitle_mutex);
    ensure_ass_track(player);
    if (!player->ass_track) {
        return fail(player, "Unable to create libass subtitle track");
    }
    AVStream *stream = player->format->streams[player->subtitle_stream];
    const int64_t pts = timestamp_us(item.packet->pts, stream->time_base);
    const int64_t duration = timestamp_us(item.packet->duration, stream->time_base);
    ass_process_chunk(player->ass_track,
                      reinterpret_cast<const char *>(item.packet->data),
                      item.packet->size, pts / 1000, duration / 1000);
    return 0;
}

void subtitle_worker(FmpPlayer *player) {
    PacketQueue &queue = player->subtitle_packets;
    try {
        for (;;) {
            if (!wait_until_playing(player)) {
                return;
            }
            QueuedPacket item;
            {
                std::unique_lock<std::mutex> lock(queue.mutex);
                queue.changed.wait(lock, [&] {
                    return player->shutting_down.load() ||
                           player->transitioning.load() ||
                           player->playback_state.load() !=
                               FmpPlayer::PlaybackState::Playing ||
                           !queue.packets.empty();
                });
                if (player->shutting_down.load()) {
                    return;
                }
                if (player->transitioning.load() ||
                    player->playback_state.load() !=
                        FmpPlayer::PlaybackState::Playing) {
                    continue;
                }
                if (queue.packets.empty()) {
                    continue;
                }
                item = std::move(queue.packets.front());
                queue.packets.pop_front();
                player->subtitle_busy.store(!item.flush);
            }
            queue.changed.notify_all();
            if (item.generation != player->generation.load()) {
                player->subtitle_busy.store(false);
                player->event_changed.notify_all();
                continue;
            }
            if (item.flush) {
                {
                    std::lock_guard<std::mutex> lock(player->event_mutex);
                    player->subtitle_done = true;
                }
                player->event_changed.notify_all();
                continue;
            }
            try {
                if (add_subtitle_packet(player, item) < 0) {
                    player->subtitle_busy.store(false);
                    player->event_changed.notify_all();
                    continue;
                }
            } catch (const std::exception &exception) {
                fail(player, std::string("Unable to process subtitle packet: ") +
                             exception.what());
            }
            player->subtitle_busy.store(false);
            player->event_changed.notify_all();
        }
    } catch (const std::bad_alloc &) {
        fail(player, "Out of memory in subtitle worker");
    } catch (const std::exception &exception) {
        fail(player, std::string("Subtitle worker failed: ") + exception.what());
    }
}

bool enqueue_packet(FmpPlayer *player, PacketQueue &queue, AVPacket *source,
                    bool flush) {
    QueuedPacket item;
    item.generation = player->generation.load();
    item.flush = flush;
    if (source) {
        item.packet = av_packet_clone(source);
        if (!item.packet) {
            fail(player, "Unable to clone demuxed packet");
            return false;
        }
    }
    std::unique_lock<std::mutex> lock(queue.mutex);
    const bool ready = queue.changed.wait_for(
        lock, std::chrono::milliseconds(100), [&] {
        return player->shutting_down.load() ||
               player->playback_state.load() != FmpPlayer::PlaybackState::Playing ||
               item.generation != player->generation.load() ||
               queue.packets.size() < 32;
    });
    if (!ready && queue.packets.size() >= 32) {
        player->force_event_delivery = true;
        return false;
    }
    if (player->shutting_down.load() ||
        player->playback_state.load() != FmpPlayer::PlaybackState::Playing ||
        item.generation != player->generation.load()) {
        return false;
    }
    queue.packets.push_back(std::move(item));
    lock.unlock();
    queue.changed.notify_all();
    return true;
}

void clear_packet_queue(PacketQueue &queue) {
    std::lock_guard<std::mutex> lock(queue.mutex);
    queue.packets.clear();
}

void notify_workers(FmpPlayer *player) {
    player->control_changed.notify_all();
    player->video_packets.changed.notify_all();
    player->audio_packets.changed.notify_all();
    player->subtitle_packets.changed.notify_all();
    player->event_changed.notify_all();
}

int next_ready_event(FmpPlayer *player) {
    std::lock_guard<std::mutex> event_lock(player->event_mutex);
    {
        std::lock_guard<std::mutex> subtitle_queue_lock(
            player->subtitle_packets.mutex);
        if (!player->subtitle_packets.packets.empty() ||
            player->subtitle_busy.load()) {
            return 3;
        }
    }
    {
        std::lock_guard<std::mutex> error_lock(player->error_mutex);
        if (!player->error.empty()) {
            return -1;
        }
    }
    const bool video_ready = player->video_stream < 0 ||
        player->video_done || !player->video_events.empty();
    const bool audio_ready = player->audio_stream < 0 ||
        player->audio_done || !player->audio_events.empty();
    if (!video_ready || !audio_ready) {
        const bool has_one_sided_event =
            player->video_events.empty() != player->audio_events.empty();
        if (has_one_sided_event) {
            const auto now = std::chrono::steady_clock::now();
            if (!player->waiting_for_stream_event) {
                player->stream_event_wait_started = now;
                player->waiting_for_stream_event = true;
            } else if (now - player->stream_event_wait_started >=
                       kEventLookaheadTimeout) {
                player->force_event_delivery = true;
            }
        } else {
            player->waiting_for_stream_event = false;
        }
        const bool force_video = player->force_event_delivery &&
            !player->video_events.empty() &&
            player->audio_events.empty();
        const bool force_audio = player->force_event_delivery &&
            !player->audio_events.empty() &&
            player->video_events.empty();
        if (!force_video && !force_audio) {
            return 2;
        }
    }
    if (player->video_events.empty() && player->audio_events.empty()) {
        player->waiting_for_stream_event = false;
        return player->demux_finished && player->video_done &&
               player->audio_done && player->subtitle_done ? 0 : 2;
    }
    if (player->audio_events.empty() ||
        (!player->video_events.empty() &&
         player->video_events.front().event.pts_us <=
             player->audio_events.front().event.pts_us)) {
        player->current = std::move(player->video_events.front());
        player->video_events.pop_front();
    } else {
        player->current = std::move(player->audio_events.front());
        player->audio_events.pop_front();
    }
    player->current.event.data = player->current.bytes.data();
    player->current.event.data_size =
        static_cast<int32_t>(player->current.bytes.size());
    player->force_event_delivery = false;
    player->waiting_for_stream_event = false;
    player->event_changed.notify_all();
    return 1;
}

int decode_until_event(FmpPlayer *player) {
    for (;;) {
        if (player->playback_state.load() != FmpPlayer::PlaybackState::Playing) {
            return FMP_NEXT_PAUSED;
        }
        const int ready = next_ready_event(player);
        if (ready != 2) {
            if (ready == 3) {
                std::unique_lock<std::mutex> lock(player->event_mutex);
                player->event_changed.wait(lock, [&] {
                    std::lock_guard<std::mutex> subtitle_lock(
                        player->subtitle_packets.mutex);
                    return player->shutting_down.load() ||
                           player->playback_state.load() !=
                               FmpPlayer::PlaybackState::Playing ||
                           (player->subtitle_packets.packets.empty() &&
                            !player->subtitle_busy.load());
                });
                if (player->playback_state.load() !=
                    FmpPlayer::PlaybackState::Playing) {
                    return FMP_NEXT_PAUSED;
                }
                continue;
            }
            return ready;
        }
        if (player->playback_state.load() != FmpPlayer::PlaybackState::Playing) {
            return FMP_NEXT_PAUSED;
        }
        if (player->demux_finished) {
            std::unique_lock<std::mutex> lock(player->event_mutex);
            const auto streams_ready = [&] {
                return player->shutting_down.load() ||
                       player->playback_state.load() !=
                           FmpPlayer::PlaybackState::Playing ||
                       [&] {
                           std::lock_guard<std::mutex> error_lock(
                               player->error_mutex);
                           return !player->error.empty();
                       }() ||
                       ((player->video_stream < 0 || player->video_done ||
                         !player->video_events.empty()) &&
                        (player->audio_stream < 0 || player->audio_done ||
                         !player->audio_events.empty()) &&
                        player->subtitle_done);
            };
            if (player->waiting_for_stream_event) {
                player->event_changed.wait_until(
                    lock, player->stream_event_wait_started +
                              kEventLookaheadTimeout,
                    streams_ready);
            } else {
                player->event_changed.wait(lock, streams_ready);
            }
            if (player->shutting_down.load()) {
                return fail(player, "Player is closing");
            }
            continue;
        }

        if (player->demux_eof_seen) {
            if (player->video_stream >= 0 && !player->video_flush_queued) {
                if (!enqueue_packet(player, player->video_packets, nullptr, true)) {
                    if (player->force_event_delivery &&
                        player->playback_state.load() ==
                            FmpPlayer::PlaybackState::Playing) {
                        continue;
                    }
                    return player->playback_state.load() ==
                        FmpPlayer::PlaybackState::Playing
                        ? fail(player, "Unable to flush video worker input")
                        : FMP_NEXT_PAUSED;
                }
                player->video_flush_queued = true;
            }
            if (player->audio_stream >= 0 && !player->audio_flush_queued) {
                if (!enqueue_packet(player, player->audio_packets, nullptr, true)) {
                    if (player->force_event_delivery &&
                        player->playback_state.load() ==
                            FmpPlayer::PlaybackState::Playing) {
                        continue;
                    }
                    return player->playback_state.load() ==
                        FmpPlayer::PlaybackState::Playing
                        ? fail(player, "Unable to flush audio worker input")
                        : FMP_NEXT_PAUSED;
                }
                player->audio_flush_queued = true;
            }
            if (!player->subtitle_flush_queued) {
                if (!enqueue_packet(player, player->subtitle_packets, nullptr, true)) {
                    if (player->force_event_delivery &&
                        player->playback_state.load() ==
                            FmpPlayer::PlaybackState::Playing) {
                        continue;
                    }
                    return player->playback_state.load() ==
                        FmpPlayer::PlaybackState::Playing
                        ? fail(player, "Unable to flush subtitle worker input")
                        : FMP_NEXT_PAUSED;
                }
                player->subtitle_flush_queued = true;
            }
            player->demux_finished = true;
            continue;
        }
        PacketQueue *queue = nullptr;
        if (player->demux_packet_pending) {
            if (player->packet->stream_index == player->video_stream) {
                queue = &player->video_packets;
            } else if (player->packet->stream_index == player->audio_stream) {
                queue = &player->audio_packets;
            } else if (player->packet->stream_index == player->subtitle_stream) {
                queue = &player->subtitle_packets;
            }
            if (queue && !enqueue_packet(player, *queue, player->packet, false)) {
                if (player->force_event_delivery &&
                    player->playback_state.load() ==
                        FmpPlayer::PlaybackState::Playing) {
                    continue;
                }
                return player->playback_state.load() ==
                    FmpPlayer::PlaybackState::Playing
                    ? fail(player, "Unable to queue demuxed media packet")
                    : FMP_NEXT_PAUSED;
            }
            av_packet_unref(player->packet);
            player->demux_packet_pending = false;
            continue;
        }

        player->demux_started = true;
        const int result = av_read_frame(player->format, player->packet);
        if (result == AVERROR_EOF) {
            player->demux_eof_seen = true;
            continue;
        }
        if (result < 0) {
            return fail_ffmpeg(player, "Unable to read media packet", result);
        }
        player->demux_packet_pending = true;
        if (player->playback_state.load() != FmpPlayer::PlaybackState::Playing) {
            return FMP_NEXT_PAUSED;
        }
    }
}

} // namespace

extern "C" {

int fmp_open(const char *path, FmpPlayer **out_player) {
    if (!path || !out_player) {
        return fail(nullptr, "Media path and player output are required");
    }
    *out_player = nullptr;
    std::unique_ptr<FmpPlayer> player(new (std::nothrow) FmpPlayer());
    if (!player) {
        return -1;
    }
    try {
        int result = avformat_open_input(&player->format, path, nullptr, nullptr);
        if (result < 0) {
            return fail_ffmpeg(player.get(), "Unable to open media file", result);
        }
        result = avformat_find_stream_info(player->format, nullptr);
        if (result < 0) {
            return fail_ffmpeg(player.get(), "Unable to read media stream information", result);
        }

        player->video_stream = av_find_best_stream(
            player->format, AVMEDIA_TYPE_VIDEO, -1, -1, nullptr, 0);
        if (player->video_stream < 0 && player->video_stream != AVERROR_STREAM_NOT_FOUND) {
            return fail_ffmpeg(player.get(), "Unable to find video stream",
                               player->video_stream);
        }
        player->audio_stream = av_find_best_stream(
            player->format, AVMEDIA_TYPE_AUDIO, -1, -1, nullptr, 0);
        if (player->audio_stream < 0 && player->audio_stream != AVERROR_STREAM_NOT_FOUND) {
            return fail_ffmpeg(player.get(), "Unable to find audio stream",
                               player->audio_stream);
        }
        if (player->video_stream < 0 && player->audio_stream < 0) {
            return fail(player.get(), "Media file has no supported audio or video stream");
        }

        for (unsigned int i = 0; i < player->format->nb_streams; ++i) {
            AVCodecParameters *parameters = player->format->streams[i]->codecpar;
            if (parameters->codec_type == AVMEDIA_TYPE_SUBTITLE &&
                (parameters->codec_id == AV_CODEC_ID_ASS ||
                 parameters->codec_id == AV_CODEC_ID_SSA)) {
                player->subtitle_stream = static_cast<int>(i);
                break;
            }
        }

        std::string decoder_error;
        if (player->video_stream >= 0) {
            player->video_decoder =
                open_decoder(player->format, player->video_stream, decoder_error);
            if (!player->video_decoder) {
                return fail(player.get(), decoder_error);
            }
        }
        if (player->audio_stream >= 0) {
            player->audio_decoder =
                open_decoder(player->format, player->audio_stream, decoder_error);
            if (!player->audio_decoder) {
                return fail(player.get(), decoder_error);
            }
            result = initialize_audio_resampler(player.get());
            if (result < 0) {
                return fail_ffmpeg(player.get(), "Unable to initialize audio resampler", result);
            }
        }

            player->packet = av_packet_alloc();
            player->video_frame = av_frame_alloc();
            player->audio_frame = av_frame_alloc();
            if (!player->packet || (player->video_stream >= 0 && !player->video_frame) ||
                (player->audio_stream >= 0 && !player->audio_frame)) {
                return fail(player.get(), "Unable to allocate FFmpeg packet and frame buffers");
            }

        if (player->video_stream >= 0) {
            int sampled_frames = 0;
            int repeated_frames = 0;
            std::string sample_error;
            sample_telecine_cadence(player.get(), sampled_frames, repeated_frames,
                                    sample_error);
            if (!sample_error.empty()) {
                return fail(player.get(), sample_error);
            }
            player->sampled_video_frames = sampled_frames;
            player->sampled_repeat_frames = repeated_frames;
        }

        player->ass_library = ass_library_init();
        if (player->ass_library) {
            player->ass_renderer = ass_renderer_init(player->ass_library);
        }
        if (!player->ass_library || !player->ass_renderer) {
            return fail(player.get(), "Unable to initialize libass");
        }
        ass_set_fonts(player->ass_renderer, nullptr, "sans-serif",
                      ASS_FONTPROVIDER_AUTODETECT, nullptr, 1);
        if (player->subtitle_stream >= 0) {
            ensure_ass_track(player.get());
            if (!player->ass_track) {
                return fail(player.get(), "Unable to initialize embedded ASS/SSA subtitles");
            }
        }

        player->video_done = player->video_stream < 0;
        player->audio_done = player->audio_stream < 0;
        if (player->video_stream >= 0) {
            player->video_thread = std::thread(stream_worker, player.get(), true);
        }
        if (player->audio_stream >= 0) {
            player->audio_thread = std::thread(stream_worker, player.get(), false);
        }
        player->subtitle_thread = std::thread(subtitle_worker, player.get());

        last_open_error.clear();
        *out_player = player.release();
        return 0;
    } catch (const std::bad_alloc &) {
        return fail(player.get(), "Out of memory while opening media file");
    } catch (const std::exception &exception) {
        return fail(player.get(), std::string("Unable to open media file: ") +
                                 exception.what());
    }
}

int fmp_get_video_frame_rate(FmpPlayer *player, int32_t *numerator,
                             int32_t *denominator) {
    int32_t profile = FMP_VIDEO_PROFILE_OTHER;
    return fmp_get_video_profile(player, &profile, numerator, denominator);
}

int fmp_get_video_profile(FmpPlayer *player, int32_t *profile,
                          int32_t *numerator, int32_t *denominator) {
    if (!player || !profile || !numerator || !denominator ||
        player->video_stream < 0) {
        return fail(player, "Player, video stream, and profile outputs are required");
    }

    AVStream *stream = player->format->streams[player->video_stream];
    AVRational frame_rate = av_guess_frame_rate(player->format, stream, nullptr);
    if (frame_rate.num <= 0 || frame_rate.den <= 0) {
        frame_rate = stream->avg_frame_rate;
    }
    if (frame_rate.num <= 0 || frame_rate.den <= 0) {
        frame_rate = stream->r_frame_rate;
    }
    if (frame_rate.num <= 0 || frame_rate.den <= 0) {
        return fail(player, "Unable to determine video frame rate");
    }

    const double detected_fps = av_q2d(frame_rate);
    const AVFieldOrder field_order =
        player->format->streams[player->video_stream]->codecpar->field_order;
    const bool interlaced_field_order =
        field_order == AV_FIELD_TT || field_order == AV_FIELD_BB ||
        field_order == AV_FIELD_TB || field_order == AV_FIELD_BT;
    if (std::abs(detected_fps - (30000.0 / 1001.0)) < 0.05 &&
        ((player->sampled_video_frames > 0 && player->sampled_repeat_frames >= 2) ||
         interlaced_field_order)) {
        *profile = FMP_VIDEO_PROFILE_NTSC_TELECINE;
        frame_rate = AVRational{30000, 1001};
    } else if (std::abs(detected_fps - (24000.0 / 1001.0)) < 0.05 ||
               std::abs(detected_fps - 24.0) < 0.05) {
        *profile = FMP_VIDEO_PROFILE_NTSC_FILM;
        frame_rate = AVRational{24000, 1001};
    } else if (std::abs(detected_fps - 25.0) < 0.05) {
        *profile = FMP_VIDEO_PROFILE_PAL_25;
        frame_rate = AVRational{25, 1};
    } else {
        *profile = FMP_VIDEO_PROFILE_OTHER;
    }

    *numerator = frame_rate.num;
    *denominator = frame_rate.den;
    clear_error(player);
    return 0;
}

int fmp_load_subtitles(FmpPlayer *player, const char *path) {
    if (!player || !path) {
        return fail(player, "Player and subtitle path are required");
    }
    if (player->demux_started) {
        return fail(player, "Subtitles must be loaded before decoding starts");
    }
    std::lock_guard<std::mutex> lock(player->subtitle_mutex);
    ASS_Track *track = ass_read_file(player->ass_library, const_cast<char *>(path), nullptr);
    if (!track) {
        return fail(player, "Unable to load ASS/SSA subtitle file");
    }
    if (player->ass_track) {
        ass_free_track(player->ass_track);
    }
    player->ass_track = track;
    player->external_subtitle_path = path;
    clear_error(player);
    return 0;
}

int fmp_next(FmpPlayer *player, FmpEvent *event) {
    if (!player || !event) {
        return fail(player, "Player and event output are required");
    }
    std::memset(event, 0, sizeof(*event));
    if (player->playback_state.load() != FmpPlayer::PlaybackState::Playing) {
        return FMP_NEXT_PAUSED;
    }
    try {
        for (;;) {
            const int result = decode_until_event(player);
            if (result <= 0) {
                return result;
            }

            FmpEvent &current = player->current.event;
            if (player->playback_range_enabled) {
                if (current.pts_us >= player->playback_range_end_us) {
                    return FMP_NEXT_EOF;
                }
                if (current.type == FMP_EVENT_VIDEO &&
                    current.pts_us < player->playback_range_start_us) {
                    continue;
                }
                if (current.type == FMP_EVENT_AUDIO) {
                    const int64_t original_pts = current.pts_us;
                    const int64_t original_frames = static_cast<int64_t>(
                        player->current.bytes.size() /
                        (static_cast<size_t>(current.channels) * sizeof(int16_t)));
                    int64_t first_frame = 0;
                    int64_t last_frame = original_frames;
                    if (original_pts < player->playback_range_start_us) {
                        first_frame = av_rescale_rnd(
                            player->playback_range_start_us - original_pts,
                            current.sample_rate, 1000000, AV_ROUND_UP);
                    }
                    const int64_t audio_end_us =
                        original_pts + av_rescale(original_frames, 1000000,
                                                  current.sample_rate);
                    if (audio_end_us > player->playback_range_end_us) {
                        last_frame = av_rescale(
                            player->playback_range_end_us - original_pts,
                            current.sample_rate, 1000000);
                    }
                    first_frame = std::clamp(first_frame, int64_t{0}, original_frames);
                    last_frame = std::clamp(last_frame, first_frame, original_frames);
                    if (first_frame == last_frame) {
                        if (original_pts < player->playback_range_start_us) {
                            continue;
                        }
                        return FMP_NEXT_EOF;
                    }

                    const size_t bytes_per_frame =
                        static_cast<size_t>(current.channels) * sizeof(int16_t);
                    const size_t first_byte =
                        static_cast<size_t>(first_frame) * bytes_per_frame;
                    const size_t last_byte =
                        static_cast<size_t>(last_frame) * bytes_per_frame;
                    if (first_byte != 0 || last_byte != player->current.bytes.size()) {
                        player->current.bytes = std::vector<uint8_t>(
                            player->current.bytes.begin() +
                                static_cast<std::ptrdiff_t>(first_byte),
                            player->current.bytes.begin() +
                                static_cast<std::ptrdiff_t>(last_byte));
                    }
                    current.pts_us = original_pts +
                        av_rescale(first_frame, 1000000, current.sample_rate);
                    current.duration_us = av_rescale(last_frame - first_frame,
                                                     1000000, current.sample_rate);
                    current.data = player->current.bytes.data();
                    current.data_size =
                        static_cast<int32_t>(player->current.bytes.size());
                }
            }
            *event = player->current.event;
            clear_error(player);
            return 1;
        }
    } catch (const std::bad_alloc &) {
        return fail(player, "Out of memory while decoding media");
    } catch (const std::exception &exception) {
        return fail(player, std::string("Unable to decode media: ") + exception.what());
    }
}

int fmp_play(FmpPlayer *player) {
    if (!player) {
        return fail(player, "Player is required");
    }
    player->playback_state.store(FmpPlayer::PlaybackState::Playing);
    notify_workers(player);
    clear_error(player);
    return 0;
}

int fmp_play_range(FmpPlayer *player, int64_t start_time_us,
                   int64_t end_time_us) {
    if (!player || start_time_us < 0 || end_time_us <= start_time_us) {
        return fail(player, "Player and a valid non-negative playback range are required");
    }
    if (fmp_seek(player, start_time_us) < 0) {
        return -1;
    }
    player->playback_range_start_us = start_time_us;
    player->playback_range_end_us = end_time_us;
    player->playback_range_enabled = true;
    player->playback_state.store(FmpPlayer::PlaybackState::Playing);
    notify_workers(player);
    clear_error(player);
    return 0;
}

int fmp_pause(FmpPlayer *player) {
    if (!player) {
        return fail(player, "Player is required");
    }
    player->playback_state.store(FmpPlayer::PlaybackState::Paused);
    notify_workers(player);
    clear_error(player);
    return 0;
}

int fmp_stop(FmpPlayer *player) {
    if (!player) {
        return fail(player, "Player is required");
    }
    player->playback_state.store(FmpPlayer::PlaybackState::Stopped);
    notify_workers(player);
    if (fmp_seek(player, 0) < 0) {
        return -1;
    }
    player->playback_range_enabled = false;
    clear_error(player);
    return 0;
}

int fmp_screenshot_with_options(const char *media_path, int64_t position_us,
                                const char *subtitle_path,
                                const FmpScreenshotOptions *options,
                                FmpScreenshot *screenshot) {
    if (!screenshot) {
        return fail(nullptr, "Screenshot output is required");
    }
    std::memset(screenshot, 0, sizeof(*screenshot));
    const FmpScreenshotBackground background = options
        ? options->background : FMP_SCREENSHOT_BACKGROUND_VIDEO;
    if (background == FMP_SCREENSHOT_BACKGROUND_CHECKERBOARD ||
        background == FMP_SCREENSHOT_BACKGROUND_TRANSPARENT) {
        if (position_us < 0) {
            return fail(nullptr, "Generated screenshot time must be non-negative");
        }
        try {
            const bool checkerboard =
                background == FMP_SCREENSHOT_BACKGROUND_CHECKERBOARD;
            if (options->width <= 0 || options->height <= 0 ||
                (checkerboard && options->square_size <= 0)) {
                return fail(nullptr, checkerboard
                    ? "Checkerboard width, height, and square size must be positive"
                    : "Transparent screenshot width and height must be positive");
            }
            const size_t width = static_cast<size_t>(options->width);
            const size_t height = static_cast<size_t>(options->height);
            if (width > static_cast<size_t>(std::numeric_limits<int32_t>::max()) / 4 ||
                height > std::numeric_limits<size_t>::max() / (width * 4)) {
                return fail(nullptr, "Generated screenshot dimensions exceed the supported size");
            }
            const size_t stride = width * 4;
            const size_t data_size = stride * height;
            if (data_size >
                static_cast<size_t>(std::numeric_limits<int32_t>::max())) {
                return fail(nullptr, "Generated screenshot exceeds the supported size");
            }

            OwnedEvent event;
            event.event.pts_us = position_us;
            event.event.width = options->width;
            event.event.height = options->height;
            event.event.stride = static_cast<int32_t>(stride);
            event.bytes.resize(data_size);
            if (checkerboard) {
                for (int32_t y = 0; y < options->height; ++y) {
                    for (int32_t x = 0; x < options->width; ++x) {
                        const bool use_first =
                            ((x / options->square_size + y / options->square_size) & 1) == 0;
                        const uint8_t *color = use_first
                            ? options->color1_rgba : options->color2_rgba;
                        std::memcpy(event.bytes.data() +
                                        static_cast<size_t>(y) * stride +
                                        static_cast<size_t>(x) * 4,
                                    color, 4);
                    }
                }
            }

            FmpPlayer subtitle_player;
            if (subtitle_path) {
                subtitle_player.ass_library = ass_library_init();
                if (!subtitle_player.ass_library) {
                    return fail(nullptr, "Unable to initialize libass for checkerboard subtitles");
                }
                subtitle_player.ass_renderer =
                    ass_renderer_init(subtitle_player.ass_library);
                if (!subtitle_player.ass_renderer) {
                    return fail(nullptr, "Unable to initialize subtitle renderer");
                }
                ass_set_fonts(subtitle_player.ass_renderer, nullptr, "sans-serif",
                              ASS_FONTPROVIDER_AUTODETECT, nullptr, 1);
                std::string subtitle_file(subtitle_path);
                subtitle_player.ass_track = ass_read_file(
                    subtitle_player.ass_library, subtitle_file.data(), nullptr);
                if (!subtitle_player.ass_track) {
                    return fail(nullptr, "Unable to load generated screenshot ASS/SSA subtitles");
                }
                if (blend_subtitles(&subtitle_player, event) < 0) {
                    return fail(nullptr, "Unable to composite generated screenshot subtitles");
                }
            }

            auto *pixels = static_cast<uint8_t *>(std::malloc(data_size));
            if (!pixels) {
                return fail(nullptr, "Unable to allocate generated screenshot");
            }
            std::memcpy(pixels, event.bytes.data(), data_size);
            screenshot->pts_us = position_us;
            screenshot->data = pixels;
            screenshot->data_size = static_cast<int32_t>(data_size);
            screenshot->width = options->width;
            screenshot->height = options->height;
            screenshot->stride = static_cast<int32_t>(stride);
            last_open_error.clear();
            return 0;
        } catch (const std::bad_alloc &) {
            return fail(nullptr, "Out of memory while creating generated screenshot");
        } catch (const std::exception &exception) {
            return fail(nullptr, std::string("Unable to create generated screenshot: ") +
                                 exception.what());
        }
    }
    if (background != FMP_SCREENSHOT_BACKGROUND_VIDEO) {
        return fail(nullptr, "Unknown screenshot background mode");
    }
    if (!media_path || position_us < 0) {
        return fail(nullptr, "Media path and non-negative screenshot position are required");
    }

    FmpPlayer *player = nullptr;
    if (fmp_open(media_path, &player) < 0) {
        return -1;
    }
    std::unique_ptr<FmpPlayer> player_guard(player);
    if (player->video_stream < 0) {
        return fail(player, "Media file has no video stream to capture");
    }
    if (subtitle_path && fmp_load_subtitles(player, subtitle_path) < 0) {
        return -1;
    }

    try {
        std::vector<uint8_t> selected_pixels;
        FmpEvent selected{};
        FmpEvent event{};
        for (;;) {
            const int result = fmp_next(player, &event);
            if (result < 0) {
                std::lock_guard<std::mutex> lock(player->error_mutex);
                last_open_error = player->error;
                return -1;
            }
            if (result == 0) {
                break;
            }
            if (event.type != FMP_EVENT_VIDEO) {
                continue;
            }
            if (event.data_size <= 0 || !event.data) {
                return fail(player, "Decoded screenshot frame has no image data");
            }
            if (event.pts_us > position_us) {
                if (selected_pixels.empty()) {
                    selected = event;
                    selected_pixels.assign(event.data, event.data + event.data_size);
                }
                break;
            }
            selected = event;
            selected_pixels.assign(event.data, event.data + event.data_size);
            if (event.pts_us == position_us) {
                break;
            }
        }
        if (selected_pixels.empty()) {
            return fail(player, "Unable to decode a video frame for screenshot");
        }
        if (selected_pixels.size() >
            static_cast<size_t>(std::numeric_limits<int32_t>::max())) {
            return fail(player, "Screenshot image exceeds the supported size");
        }
        auto *pixels = static_cast<uint8_t *>(std::malloc(selected_pixels.size()));
        if (!pixels) {
            return fail(player, "Unable to allocate screenshot image");
        }
        std::memcpy(pixels, selected_pixels.data(), selected_pixels.size());
        screenshot->pts_us = selected.pts_us;
        screenshot->data = pixels;
        screenshot->data_size = static_cast<int32_t>(selected_pixels.size());
        screenshot->width = selected.width;
        screenshot->height = selected.height;
        screenshot->stride = selected.stride;
        clear_error(player);
        last_open_error.clear();
        return 0;
    } catch (const std::bad_alloc &) {
        return fail(player, "Out of memory while capturing screenshot");
    } catch (const std::exception &exception) {
        return fail(player, std::string("Unable to capture screenshot: ") +
                            exception.what());
    }
}

int fmp_screenshot(const char *media_path, int64_t position_us,
                   const char *subtitle_path, FmpScreenshot *screenshot) {
    return fmp_screenshot_with_options(media_path, position_us, subtitle_path,
                                       nullptr, screenshot);
}

void fmp_screenshot_free(FmpScreenshot *screenshot) {
    if (!screenshot) {
        return;
    }
    std::free(screenshot->data);
    std::memset(screenshot, 0, sizeof(*screenshot));
}

int fmp_seek(FmpPlayer *player, int64_t position_us) {
    if (!player || position_us < 0) {
        return fail(player, "Player and non-negative seek position are required");
    }
    player->transitioning.store(true);
    player->generation.fetch_add(1);
    notify_workers(player);

    clear_packet_queue(player->video_packets);
    clear_packet_queue(player->audio_packets);
    clear_packet_queue(player->subtitle_packets);
    {
        std::lock_guard<std::mutex> lock(player->event_mutex);
        player->video_events.clear();
        player->audio_events.clear();
        player->current = OwnedEvent{};
        player->video_done = player->video_stream < 0;
        player->audio_done = player->audio_stream < 0;
        player->subtitle_done = false;
        player->subtitle_busy.store(false);
    }
    player->event_changed.notify_all();

    std::unique_lock<std::mutex> video_lock(player->video_decoder_mutex,
                                           std::defer_lock);
    std::unique_lock<std::mutex> audio_lock(player->audio_decoder_mutex,
                                           std::defer_lock);
    if (player->video_decoder) video_lock.lock();
    if (player->audio_decoder) audio_lock.lock();
    const int64_t target = av_rescale_q(position_us, AVRational{1, 1000000},
                                        AV_TIME_BASE_Q);
    const int result = av_seek_frame(player->format, -1, target, AVSEEK_FLAG_BACKWARD);
    if (result < 0) {
        player->transitioning.store(false);
        notify_workers(player);
        return fail_ffmpeg(player, "Unable to seek in media file", result);
    }
    if (player->video_decoder) {
        avcodec_flush_buffers(player->video_decoder);
    }
    if (player->audio_decoder) {
        avcodec_flush_buffers(player->audio_decoder);
    }
    if (player->resampler) {
        swr_close(player->resampler);
        const int resampler_result = swr_init(player->resampler);
        if (resampler_result < 0) {
            player->transitioning.store(false);
            notify_workers(player);
            return fail_ffmpeg(player, "Unable to reset audio resampler",
                               resampler_result);
        }
    }
    if (video_lock.owns_lock()) video_lock.unlock();
    if (audio_lock.owns_lock()) audio_lock.unlock();

    {
        std::lock_guard<std::mutex> lock(player->subtitle_mutex);
        ASS_Track *track = nullptr;
        if (!player->external_subtitle_path.empty()) {
            track = ass_read_file(player->ass_library,
                                  player->external_subtitle_path.data(), nullptr);
            if (!track) {
                player->transitioning.store(false);
                notify_workers(player);
                return fail(player, "Unable to reload external subtitles after seeking");
            }
        } else {
            track = ass_new_track(player->ass_library);
            if (track && player->subtitle_stream >= 0) {
                AVCodecParameters *parameters =
                    player->format->streams[player->subtitle_stream]->codecpar;
                if (parameters->extradata && parameters->extradata_size > 0) {
                    ass_process_codec_private(track,
                        reinterpret_cast<const char *>(parameters->extradata),
                        parameters->extradata_size);
                }
            }
            if (!track) {
                player->transitioning.store(false);
                notify_workers(player);
                return fail(player, "Unable to reset embedded subtitles after seeking");
            }
        }
        if (player->ass_track) ass_free_track(player->ass_track);
        player->ass_track = track;
    }

    player->demux_finished = false;
    player->demux_started = true;
    player->demux_packet_pending = false;
    player->demux_eof_seen = false;
    player->force_event_delivery = false;
    player->waiting_for_stream_event = false;
    player->video_flush_queued = false;
    player->audio_flush_queued = false;
    player->subtitle_flush_queued = false;
    av_packet_unref(player->packet);
    player->last_audio_end_pts_us = position_us;
    clear_error(player);
    player->transitioning.store(false);
    notify_workers(player);
    return 0;
}

int fmp_get_error(FmpPlayer *player, char *buffer, int32_t buffer_size) {
    if (!buffer || buffer_size <= 0) {
        return -1;
    }
    std::string error;
    if (player) {
        std::lock_guard<std::mutex> lock(player->error_mutex);
        error = player->error;
    } else {
        error = last_open_error;
    }
    const size_t copy_size = std::min(
        error.size(), static_cast<size_t>(buffer_size - 1));
    std::memcpy(buffer, error.data(), copy_size);
    buffer[copy_size] = '\0';
    return static_cast<int>(copy_size);
}

void fmp_close(FmpPlayer *player) {
    delete player;
}

} // extern "C"
