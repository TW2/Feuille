# FMP — FFmpeg Media Playback for Java

FMP is a C++17 shared library that decodes media with FFmpeg and exposes a
plain C API for Java/JNA applications. libass composites embedded ASS/SSA
subtitles or an optional external ASS/SSA file onto decoded video frames.

The native library provides timestamped RGBA video frames and 48 kHz stereo
signed 16-bit little-endian PCM audio. It does not create a window or access
an audio device: Java owns presentation and playback output. The included
[Swing/JNA player](./examples/java-player/src/main/java/FmpSwingPlayer.java) demonstrates video in a
`JPanel`, audio through Java Sound, and synchronized **Play**, **Pause**, and
**Stop** controls. The C API also supports standalone screenshots without
starting playback.

## Features

- FFmpeg demuxing and decoding of the best-matching audio/video streams.
- Separate native audio, video, and subtitle worker threads.
- Timestamped RGBA frames and timestamped PCM events for Java playback.
- Embedded and external ASS/SSA subtitle rendering through libass.
- Native play, pause, and stop/rewind controls for the decoder event stream.
- Standalone screenshot capture at a requested media timestamp, with optional
  subtitle composition, or a generated checkerboard background with
  caller-selected colors.
- Stable C ABI with explicit error messages, intended for JNA integration.
- Runnable Swing and Java Sound example with unified audio/video controls.

## Project layout

| Path | Purpose |
| --- | --- |
| `include/fmp/fmp.h` | Public C/JNA ABI, including video frame-rate query |
| `src/fmp.cpp` | FFmpeg decoding, libass composition, screenshots and controls |
| `examples/java-player/` | Runnable Maven/Swing/JNA players, including configurable-FPS mode |
| `CMakeLists.txt` | Native build and install configuration |

## Dependencies

- CMake 3.16+
- C++17 compiler
- FFmpeg development libraries: `libavformat`, `libavcodec`, `libavutil`,
  `libswscale`, and `libswresample`
- libass development library
- pkg-config

On Debian/Ubuntu, install them with:

```sh
sudo apt install build-essential cmake pkg-config \
  libavformat-dev libavcodec-dev libavutil-dev libswscale-dev \
  libswresample-dev libass-dev
```

## Build

```sh
cmake -S . -B build -DCMAKE_BUILD_TYPE=Release
cmake --build build
```

The shared library is `build/libfmp.so` on Linux. Install it and the public
header with:

```sh
cmake --install build --prefix install
```

## Java/JNA integration

Add JNA to the Java application (for example, `net.java.dev.jna:jna`) and make
the native library discoverable. On Linux, set
`-Djna.library.path=/absolute/path/to/fmp/build`. The example loads the
platform library by the name `fmp` using `Native.load`.

The JNA declarations below map the native pointers to `Pointer`, `int32_t` to
`int`, `int64_t` to `long`, and the native structs to `Structure`. Keep the
field order exactly as shown:

```java
import com.sun.jna.*;
import com.sun.jna.ptr.*;
import java.awt.image.BufferedImage;

public final class FmpJna {
    @Structure.FieldOrder({"type", "pts_us", "duration_us", "data", "data_size",
            "width", "height", "stride", "sample_rate", "channels"})
    public static class FmpEvent extends Structure {
        public int type; // 1 = video, 2 = audio
        public long pts_us;
        public long duration_us;
        public Pointer data;
        public int data_size;
        public int width;
        public int height;
        public int stride;
        public int sample_rate;
        public int channels;
    }

    @Structure.FieldOrder({"pts_us", "data", "data_size", "width", "height", "stride"})
    public static class FmpScreenshot extends Structure {
        public long pts_us;
        public Pointer data;
        public int data_size;
        public int width;
        public int height;
        public int stride;
    }

    @Structure.FieldOrder({"background", "width", "height", "square_size",
            "color1_rgba", "color2_rgba"})
    public static class FmpScreenshotOptions extends Structure {
        public int background; // 0 = video, 1 = checkerboard
        public int width;
        public int height;
        public int square_size;
        public byte[] color1_rgba = new byte[4];
        public byte[] color2_rgba = new byte[4];
    }

    public interface NativeApi extends Library {
        int fmp_open(String path, PointerByReference outPlayer);
        int fmp_get_video_frame_rate(Pointer player, IntByReference numerator,
                                     IntByReference denominator);
        int fmp_load_subtitles(Pointer player, String subtitlePath);
        int fmp_next(Pointer player, FmpEvent event);
        int fmp_play(Pointer player);
        int fmp_pause(Pointer player);
        int fmp_stop(Pointer player);
        int fmp_seek(Pointer player, long positionUs);
        int fmp_screenshot(String mediaPath, long positionUs, String subtitlePath,
                           FmpScreenshot screenshot);
        int fmp_screenshot_with_options(
                String mediaPath, long positionUs, String subtitlePath,
                FmpScreenshotOptions options, FmpScreenshot screenshot);
        void fmp_screenshot_free(FmpScreenshot screenshot);
        int fmp_get_error(Pointer player, byte[] buffer, int bufferSize);
        void fmp_close(Pointer player);
    }

    private static final NativeApi NATIVE = Native.load("fmp", NativeApi.class);

    private static String error(Pointer player) {
        byte[] buffer = new byte[1024];
        int length = NATIVE.fmp_get_error(player, buffer, buffer.length);
        if (length < 0) return "Native FMP error";
        return new String(buffer, 0, length, java.nio.charset.StandardCharsets.UTF_8);
    }

    /** Suitable for a Java HTTP/service endpoint returning an image. */
    public static BufferedImage screenshot(String mediaPath, long positionUs,
                                           String subtitlePath) {
        FmpScreenshot image = new FmpScreenshot();
        int result = NATIVE.fmp_screenshot(mediaPath, positionUs, subtitlePath, image);
        if (result != 0) {
            throw new IllegalArgumentException(error(null));
        }
        image.read();
        try {
            byte[] rgba = image.data.getByteArray(0, image.data_size);
            BufferedImage output =
                    new BufferedImage(image.width, image.height, BufferedImage.TYPE_INT_ARGB);
            int[] row = new int[image.width];
            for (int y = 0; y < image.height; y++) {
                int offset = y * image.stride;
                for (int x = 0; x < image.width; x++) {
                    int p = offset + x * 4;
                    int r = rgba[p] & 0xff;
                    int g = rgba[p + 1] & 0xff;
                    int b = rgba[p + 2] & 0xff;
                    int a = rgba[p + 3] & 0xff;
                    row[x] = (a << 24) | (r << 16) | (g << 8) | b;
                }
                output.setRGB(0, y, image.width, 1, row, 0, image.width);
            }
            return output;
        } finally {
            NATIVE.fmp_screenshot_free(image);
        }
    }
}
```

For an HTTP endpoint, call `FmpJna.screenshot(mediaPath, positionUs,
subtitlePath)` and encode the returned `BufferedImage` with
`ImageIO.write(image, "png", responseOutputStream)`. The timestamp is in
microseconds (`2_500_000` means 2.5 seconds); pass `null` for no external
subtitle file. The screenshot call opens and closes its own decoder, so it can
be used independently of playback. Video screenshot calls open and close their
own decoder. Always free the native screenshot buffer; the example does this
in `finally` after copying pixels into Java memory.

To generate a checkerboard without a media file, configure the screenshot
options with `background = 1`, the desired pixel dimensions and square size,
and each color as four RGBA bytes, then call:

```java
FmpScreenshotOptions options = new FmpScreenshotOptions();
options.background = 1;
options.width = 640;
options.height = 360;
options.square_size = 32;
options.color1_rgba = new byte[] {(byte) 0xff, (byte) 0xff, (byte) 0xff, (byte) 0xff};
options.color2_rgba = new byte[] {0, 0, 0, (byte) 0xff};

FmpScreenshot image = new FmpScreenshot();
int result = NATIVE.fmp_screenshot_with_options(
        null, 500_000, "subtitles.ass", options, image);
if (result != 0) throw new IllegalArgumentException(error(null));
image.read();
try {
    byte[] rgba = image.data.getByteArray(0, image.data_size);
    // Convert the packed RGBA pixels to the desired image format.
} finally {
    NATIVE.fmp_screenshot_free(image);
}
```

The checkerboard option does not open or require a video file. Pass an external
ASS/SSA file as `subtitlePath` to draw its active subtitle over the pattern at
`positionUs` (500,000 microseconds in the example); pass `null` for none.
Embedded subtitles are unavailable in checkerboard mode because there is no
media input. Square colors alternate from the upper-left corner, and generated
images use the same top-to-bottom packed RGBA format as decoded video
screenshots. Existing `fmp_screenshot()` calls retain their video behavior.

### Swing video and Java Sound playback

The runnable examples at
[examples/java-player/src/main/java/FmpSwingPlayer.java](./examples/java-player/src/main/java/FmpSwingPlayer.java)
connect `presentVideo()` to a Swing `JPanel` and `queueAudio()` to Java Sound's
`SourceDataLine`. Audio and video arrive as separate timestamped events; the
player writes audio events to the device as they arrive and presents each video
frame when its timestamp is due against the audio device's playback clock.
Audio and video do not need matching event boundaries or timestamps. The
window's **Play**, **Pause**, and **Stop** buttons control both outputs through
one `PlaybackController`; stop rewinds to the beginning.

The decoder no longer sleeps for each video presentation timestamp. It keeps
decoding audio/video packets while Swing presents due frames against the audio
clock; a small bounded frame queue discards stale frames if decoding temporarily
runs ahead. RGBA conversion writes directly into the destination image buffer
to reduce per-frame overhead.

The tiny Maven project pins JNA 5.19.1, the latest stable release, and targets
Java 17 bytecode for broad runtime compatibility (including the latest JDK).
Build the native library first, then compile and launch from the repository
root:

```sh
mvn -f examples/java-player/pom.xml package
mvn -f examples/java-player/pom.xml exec:java \
  -Djna.library.path="$PWD/build" \
  -Dexec.args="video.mkv subtitles.ass"
```

Omit `subtitles.ass` when no external subtitle file is needed. The Maven
project downloads JNA and its build plugins automatically. Its standalone
project files are [pom.xml](./examples/java-player/pom.xml) and
[FmpSwingPlayer.java](./examples/java-player/src/main/java/FmpSwingPlayer.java).

On open, the native player samples up to 120 decoded video frames and checks
FFmpeg's repeat-field metadata and the stream's interlaced field-order metadata
for telecine evidence. If a 29.97 FPS stream has repeat-field evidence or is
marked interlaced, it reports the NTSC telecine profile at 30000/1001.
Non-telecined 23.976/24 FPS film is normalized to 24000/1001. A 25 FPS PAL
stream is reported as 25/1; PAL rates other than 25 and other standards retain
FFmpeg's estimated rate. If no usable estimate is available, Java uses a
30 FPS scheduling fallback. The UI title displays the detected profile.
Sampling adds some media-open time, especially on long-GOP sources. Interlaced
29.97 FPS material is used as a telecine fallback signal when repeat-field
flags are unavailable; as with any metadata-based heuristic, native interlaced
video can be indistinguishable from telecine without a deeper field-cadence
analysis.

The video scheduler uses the reported effective frame rate for its cadence,
but frame presentation timestamps remain the A/V synchronization source.
Variable-frame-rate material therefore follows actual timestamps.

### Native stream workers

Each player uses separate native worker threads for audio decoding, video
decoding, and subtitle packet processing. `fmp_next()` remains the serialized
demux/event interface: it dispatches packets into bounded queues and returns
audio/video events ordered by their presentation timestamps when both streams
have events ready. If only one stream has an event ready, a 50 ms lookahead
timeout (or packet-queue pressure) lets it through rather than waiting
indefinitely for the other stream. Callers should use event timestamps for
presentation synchronization. Subtitle packets are processed independently,
and the subtitle track is synchronized with video composition.

Pause and seek transitions wake the workers. Seeking invalidates queued work,
flushes the decoders, and resets embedded or external subtitle state before
decoding resumes. Calls that operate on one player handle should still be
serialized by the application; the internal stream workers are managed by the
native library.

An alternate, source-frame-rate-focused entry point is available as
`FmpFpsPlayer`; it uses the same automatic source-FPS scheduling:

```sh
mvn -f examples/java-player/pom.xml exec:java \
  -Dexec.mainClass=FmpFpsPlayer \
  -Djna.library.path="$PWD/build" \
  -Dexec.args="video.mkv subtitles.ass"
```

The displayed cadence is still limited by the monitor refresh rate and system
performance. Calls into the native player are serialized on the decoder thread
because a player handle is not thread-safe. Java Sound and display output
remain owned by Java.

## C API notes

### Playback and event contract

Typical playback flow:

1. Call `fmp_open(path, &player)`. A new player starts in the playing state.
2. Call `fmp_get_video_profile(player, &profile, &numerator, &denominator)`
   to get the detected profile and effective frame rate. Available profile
   values are `FMP_VIDEO_PROFILE_NTSC_TELECINE`,
   `FMP_VIDEO_PROFILE_NTSC_FILM`, `FMP_VIDEO_PROFILE_PAL_25`, and
   `FMP_VIDEO_PROFILE_OTHER`. The simpler `fmp_get_video_frame_rate()` returns
   the same normalized rate without the profile.
3. Optionally call `fmp_load_subtitles(player, subtitlePath)` before reading
   events. This replaces any embedded subtitle track.
4. Call `fmp_next(player, &event)` to decode events. It returns `1` for an
   event, `0` at EOF, `2` when paused/stopped, or `-1` on error.
5. Copy `event.data` before the next `fmp_next()` call; its memory is owned by
   the player and reused. Use the event presentation timestamp (`pts_us`) to
   synchronize Java video and audio output.
6. Call `fmp_close(player)` when finished.

`fmp_pause(player)` pauses event delivery; `fmp_play(player)` resumes it.
`fmp_stop(player)` seeks to the beginning and stops event delivery; call
`fmp_play()` to start again. These controls do not operate Java's audio device.
The Java application must pause or flush audio it has already queued when
pausing or stopping. Calls made using one player handle must be serialized;
player handles are not thread-safe.

`event.data` is owned by the player and remains valid only until the next
`fmp_next()` call or `fmp_close()`. A Java caller should copy the bytes before
requesting another event if it needs to retain them. Video events contain
top-to-bottom packed RGBA pixels (`stride` bytes per row). Audio events contain
interleaved 48 kHz stereo signed 16-bit little-endian PCM. Only the
best-matching audio/video streams are decoded. Embedded subtitles are
currently supported for ASS/SSA tracks; external subtitle files should also be
ASS/SSA.

### Standalone screenshot capture

Call `fmp_screenshot(mediaPath, positionUs, subtitlePath, &screenshot)` to
capture a still without starting playback. It opens its own decoder and does
not change an existing player's position. It returns the video frame at or
immediately before `positionUs` as packed RGBA and composites embedded
subtitles or the optional external ASS/SSA subtitle file. A request before the
first frame returns the first frame; a request beyond the end returns the last
frame. Release its allocated image with `fmp_screenshot_free(&screenshot)`.
The screenshot API is useful for thumbnails and HTTP image endpoints; the
JNA `BufferedImage` example above shows how to copy and convert its pixels.

For a generated checkerboard without any media input, call
`fmp_screenshot_with_options(NULL, 0, NULL, &options, &screenshot)` with
`options.background` set to `FMP_SCREENSHOT_BACKGROUND_CHECKERBOARD`. Set
positive `width`, `height`, and `square_size` values and provide two 8-bit RGBA
colors. To composite an external ASS/SSA subtitle, pass its path and the
desired non-negative timestamp in microseconds instead of `NULL` and `0`;
only cues active at that timestamp appear. The result uses the same screenshot
structure and must be released with `fmp_screenshot_free()`. Set the
background to `FMP_SCREENSHOT_BACKGROUND_VIDEO` (or pass null options) for the
original video-frame behavior.

### Errors and ABI

For a player operation, call `fmp_get_error(player, buffer, bufferSize)` to
copy the diagnostic into caller-owned memory. If `fmp_open()` or
`fmp_screenshot()` fails before returning a player handle, pass `NULL` to
`fmp_get_error`; the open/screenshot error is thread-local, so retrieve it on
the same Java thread.

The native API is declared in `fmp/fmp.h`. JNA maps opaque player handles and
data pointers to `Pointer`, `int32_t` to `int`, and `int64_t` to `long`.
Structure field order must match the C declarations exactly. See the Java
examples above for complete mappings and native-memory ownership handling.
