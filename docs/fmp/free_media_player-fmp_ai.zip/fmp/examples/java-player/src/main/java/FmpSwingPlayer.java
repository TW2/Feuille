import com.sun.jna.Library;
import com.sun.jna.Native;
import com.sun.jna.Pointer;
import com.sun.jna.Structure;
import com.sun.jna.ptr.IntByReference;
import com.sun.jna.ptr.PointerByReference;

import javax.sound.sampled.AudioFormat;
import javax.sound.sampled.AudioSystem;
import javax.sound.sampled.DataLine;
import javax.sound.sampled.SourceDataLine;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.SwingUtilities;
import javax.swing.Timer;
import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.RenderingHints;
import java.awt.image.BufferedImage;
import java.awt.image.DataBufferInt;
import java.nio.charset.StandardCharsets;
import java.util.ArrayDeque;
import java.util.concurrent.atomic.AtomicBoolean;

public final class FmpSwingPlayer {
    private static final int EVENT_VIDEO = 1;
    private static final int EVENT_AUDIO = 2;
    private static final int NEXT_ERROR = -1;
    private static final int NEXT_EOF = 0;
    private static final int NEXT_EVENT = 1;
    private static final int NEXT_PAUSED = 2;
    private static final int AUDIO_RATE = 48_000;
    private static final int FALLBACK_FPS = 30;
    private static final int MAX_QUEUED_VIDEO_FRAMES = 5;

    @Structure.FieldOrder({"type", "pts_us", "duration_us", "data", "data_size",
            "width", "height", "stride", "sample_rate", "channels"})
    public static class FmpEvent extends Structure {
        public int type;
        public long pts_us;
        public long duration_us;
        public Pointer data;
        public int data_size;
        public int width;
        public int height;
        public int stride;
        public int sample_rate;
        public int channels;
    }

    private interface FmpNative extends Library {
        int fmp_open(String path, PointerByReference outPlayer);
        int fmp_get_video_profile(Pointer player, IntByReference profile,
                                  IntByReference numerator, IntByReference denominator);
        int fmp_load_subtitles(Pointer player, String subtitlePath);
        int fmp_next(Pointer player, FmpEvent event);
        int fmp_play(Pointer player);
        int fmp_pause(Pointer player);
        int fmp_stop(Pointer player);
        int fmp_get_error(Pointer player, byte[] buffer, int bufferSize);
        void fmp_close(Pointer player);
    }

    private static final FmpNative NATIVE = Native.load("fmp", FmpNative.class);

    private static final class VideoFrame {
        final long ptsUs;
        final BufferedImage image;

        VideoFrame(long ptsUs, BufferedImage image) {
            this.ptsUs = ptsUs;
            this.image = image;
        }
    }

    private static final class VideoPanel extends JPanel {
        private static final long serialVersionUID = 1L;
        private transient BufferedImage frame;

        VideoPanel() {
            setPreferredSize(new Dimension(960, 540));
            setBackground(Color.BLACK);
        }

        void setFrame(BufferedImage nextFrame) {
            if (SwingUtilities.isEventDispatchThread()) {
                frame = nextFrame;
                repaint();
            } else {
                SwingUtilities.invokeLater(() -> setFrame(nextFrame));
            }
        }

        @Override
        protected void paintComponent(Graphics graphics) {
            super.paintComponent(graphics);
            if (frame == null) return;

            int panelWidth = getWidth();
            int panelHeight = getHeight();
            double scale = Math.min(
                    (double) panelWidth / frame.getWidth(),
                    (double) panelHeight / frame.getHeight());
            int width = (int) Math.round(frame.getWidth() * scale);
            int height = (int) Math.round(frame.getHeight() * scale);
            int x = (panelWidth - width) / 2;
            int y = (panelHeight - height) / 2;

            Graphics2D g = (Graphics2D) graphics.create();
            g.setRenderingHint(RenderingHints.KEY_INTERPOLATION,
                    RenderingHints.VALUE_INTERPOLATION_BILINEAR);
            g.drawImage(frame, x, y, width, height, null);
            g.dispose();
        }
    }

    private static final class PlaybackController implements AutoCloseable {
        private enum State { PLAYING, PAUSED, STOPPED }

        private final Object stateLock = new Object();
        private final Object frameLock = new Object();
        private final ArrayDeque<VideoFrame> frames = new ArrayDeque<>();
        private final AtomicBoolean closed = new AtomicBoolean();
        private final Pointer player;
        private final VideoPanel videoPanel;
        private final SourceDataLine audioLine;
        private final Timer videoTimer;
        private final Thread worker;
        private final long presentationIntervalNanos;

        private volatile State requestedState = State.STOPPED;
        private volatile long generation;
        private State appliedState;
        private volatile boolean audioClockReady;
        private long audioClockBasePtsUs;
        private long audioClockBaseFrame;
        private long audioFramesWritten;
        private long fallbackClockBasePtsUs;
        private long fallbackClockBaseNanos = System.nanoTime();
        private long nextPresentationNanos;
        private final String sourceVideoProfile;

        PlaybackController(String mediaPath, String subtitlePath, VideoPanel panel)
                throws Exception {
            videoPanel = panel;
            PointerByReference outPlayer = new PointerByReference();
            if (NATIVE.fmp_open(mediaPath, outPlayer) != 0) {
                throw new IllegalArgumentException(nativeError(null));
            }
            player = outPlayer.getValue();
            if (player == null) {
                throw new IllegalStateException("Native FMP returned a null player handle");
            }

            IntByReference fpsNumerator = new IntByReference();
            IntByReference fpsDenominator = new IntByReference();
            IntByReference profile = new IntByReference();
            double sourceFps = FALLBACK_FPS;
            if (NATIVE.fmp_get_video_profile(
                    player, profile, fpsNumerator, fpsDenominator) == 0 &&
                    fpsNumerator.getValue() > 0 && fpsDenominator.getValue() > 0) {
                sourceFps = (double) fpsNumerator.getValue() /
                        fpsDenominator.getValue();
            }
            if (!Double.isFinite(sourceFps) || sourceFps <= 0.0) {
                sourceFps = FALLBACK_FPS;
            }
            sourceVideoProfile = switch (profile.getValue()) {
                case 1 -> "NTSC telecine";
                case 2 -> "NTSC film";
                case 3 -> "PAL 25";
                default -> String.format(
                        java.util.Locale.ROOT, "other %.3f FPS", sourceFps);
            };

            if (subtitlePath != null &&
                    NATIVE.fmp_load_subtitles(player, subtitlePath) != 0) {
                String message = nativeError(player);
                NATIVE.fmp_close(player);
                throw new IllegalArgumentException(message);
            }

            AudioFormat format = new AudioFormat(AUDIO_RATE, 16, 2, true, false);
            DataLine.Info info = new DataLine.Info(SourceDataLine.class, format);
            SourceDataLine openedAudioLine = null;
            try {
                if (!AudioSystem.isLineSupported(info)) {
                    throw new IllegalStateException(
                            "No Java Sound output supports 48 kHz stereo PCM");
                }
                openedAudioLine = (SourceDataLine) AudioSystem.getLine(info);
                openedAudioLine.open(format, 8192);
            } catch (Exception exception) {
                if (openedAudioLine != null) openedAudioLine.close();
                NATIVE.fmp_close(player);
                throw exception;
            }
            audioLine = openedAudioLine;

            presentationIntervalNanos = Math.max(1L,
                    Math.round(1_000_000_000.0 / sourceFps));
            videoTimer = new Timer(4, event -> presentDueVideo());
            videoTimer.setCoalesce(true);
            videoTimer.start();
            worker = new Thread(this::decodeLoop, "fmp-decoder");
            worker.start();
        }

        void play() {
            request(State.PLAYING);
        }

        void pause() {
            request(State.PAUSED);
        }

        void stop() {
            generation++;
            request(State.STOPPED);
            synchronized (frameLock) {
                frames.clear();
                frameLock.notifyAll();
            }
            videoPanel.setFrame(null);
        }

        private void request(State state) {
            synchronized (stateLock) {
                requestedState = state;
                stateLock.notifyAll();
            }
        }

        private void decodeLoop() {
            try {
                while (!closed.get()) {
                    applyRequestedState();
                    if (closed.get()) break;
                    if (appliedState != State.PLAYING) {
                        synchronized (stateLock) {
                            if (!closed.get() && requestedState == appliedState) {
                                stateLock.wait();
                            }
                        }
                        continue;
                    }

                    long eventGeneration = generation;
                    FmpEvent event = new FmpEvent();
                    int status = NATIVE.fmp_next(player, event);
                    if (status == NEXT_PAUSED) continue;
                    if (status == NEXT_EOF) {
                        waitForAudioToFinish();
                        if (requestedState != State.STOPPED) presentLastQueuedVideo();
                        NATIVE.fmp_stop(player);
                        appliedState = State.STOPPED;
                        requestedState = State.STOPPED;
                        audioLine.stop();
                        audioLine.flush();
                        resetAudioClock();
                        continue;
                    }
                    if (status == NEXT_ERROR) {
                        throw new IllegalStateException(nativeError(player));
                    }
                    if (status != NEXT_EVENT) {
                        throw new IllegalStateException("Unknown fmp_next result: " + status);
                    }

                    event.read();
                    if (event.data == null || event.data_size <= 0) continue;
                    byte[] data = event.data.getByteArray(0, event.data_size);
                    if (generation != eventGeneration) continue;
                    if (event.type == EVENT_VIDEO) {
                        presentVideo(data, event.width, event.height, event.stride,
                                event.pts_us, eventGeneration);
                        waitForVideoClockIfNeeded(event.pts_us, eventGeneration);
                    } else if (event.type == EVENT_AUDIO) {
                        queueAudio(data, event.sample_rate, event.channels,
                                event.pts_us, eventGeneration);
                    }
                }
            } catch (InterruptedException exception) {
                Thread.currentThread().interrupt();
            } catch (Exception exception) {
                closed.set(true);
                SwingUtilities.invokeLater(videoTimer::stop);
                SwingUtilities.invokeLater(() -> JOptionPane.showMessageDialog(
                        videoPanel, exception.getMessage(), "FMP playback error",
                        JOptionPane.ERROR_MESSAGE));
            } finally {
                NATIVE.fmp_close(player);
                audioLine.stop();
                audioLine.close();
            }
        }

        private void applyRequestedState() {
            State requested = requestedState;
            if (requested == appliedState) return;

            if (requested == State.PLAYING) {
                if (NATIVE.fmp_play(player) != 0) {
                    throw new IllegalStateException(nativeError(player));
                }
                fallbackClockBaseNanos = System.nanoTime();
                audioLine.start();
            } else if (requested == State.PAUSED) {
                fallbackClockBasePtsUs = currentClockUs();
                fallbackClockBaseNanos = System.nanoTime();
                if (NATIVE.fmp_pause(player) != 0) {
                    throw new IllegalStateException(nativeError(player));
                }
                audioLine.stop();
            } else {
                audioLine.stop();
                audioLine.flush();
                if (NATIVE.fmp_stop(player) != 0) {
                    throw new IllegalStateException(nativeError(player));
                }
                resetAudioClock();
            }
            appliedState = requested;
        }

        private void presentVideo(byte[] rgba, int width, int height, int stride,
                                  long ptsUs, long eventGeneration) {
            if (width <= 0 || height <= 0 || stride < (long) width * 4 ||
                    rgba.length < (long) stride * height) {
                throw new IllegalArgumentException("Invalid decoded RGBA video frame");
            }
            BufferedImage image = new BufferedImage(
                    width, height, BufferedImage.TYPE_INT_ARGB);
            int[] pixels = ((DataBufferInt) image.getRaster().getDataBuffer()).getData();
            for (int y = 0; y < height; y++) {
                int offset = y * stride;
                int targetOffset = y * width;
                for (int x = 0; x < width; x++) {
                    int pixel = offset + x * 4;
                    int red = rgba[pixel] & 0xff;
                    int green = rgba[pixel + 1] & 0xff;
                    int blue = rgba[pixel + 2] & 0xff;
                    int alpha = rgba[pixel + 3] & 0xff;
                    pixels[targetOffset + x] =
                            (alpha << 24) | (red << 16) | (green << 8) | blue;
                }
            }

            synchronized (frameLock) {
                if (generation != eventGeneration || requestedState != State.PLAYING) return;
                while (frames.size() >= MAX_QUEUED_VIDEO_FRAMES) {
                    frames.removeFirst();
                }
                frames.addLast(new VideoFrame(ptsUs, image));
                if (frames.size() == 1 && !audioClockReady) {
                    fallbackClockBasePtsUs = ptsUs;
                    fallbackClockBaseNanos = System.nanoTime();
                }
            }
        }

        private void presentDueVideo() {
            long now = System.nanoTime();
            if (now < nextPresentationNanos) return;
            VideoFrame due = null;
            long clockUs = currentClockUs();
            synchronized (frameLock) {
                while (!frames.isEmpty() && frames.peekFirst().ptsUs <= clockUs) {
                    due = frames.removeFirst();
                }
                frameLock.notifyAll();
            }
            if (due != null) {
                videoPanel.setFrame(due.image);
                nextPresentationNanos = now + presentationIntervalNanos;
            }
        }

        private void presentLastQueuedVideo() {
            VideoFrame last = null;
            synchronized (frameLock) {
                while (!frames.isEmpty()) last = frames.removeFirst();
            }
            if (last != null) videoPanel.setFrame(last.image);
        }

        private void waitForVideoClockIfNeeded(long ptsUs, long eventGeneration)
                throws InterruptedException {
            while (!closed.get() && generation == eventGeneration &&
                    !audioClockReady && currentClockUs() < ptsUs) {
                if (requestedState != appliedState) applyRequestedState();
                if (requestedState == State.PLAYING) {
                    Thread.sleep(2);
                } else {
                    waitForStateChange();
                }
            }
        }

        private void queueAudio(byte[] pcm, int sampleRate, int channels,
                                long ptsUs, long eventGeneration) {
            if (sampleRate != AUDIO_RATE || channels != 2 || (pcm.length & 3) != 0) {
                throw new IllegalArgumentException("Unexpected decoded PCM audio format");
            }
            if (!audioClockReady) {
                audioClockBasePtsUs = ptsUs;
                audioClockBaseFrame = audioLine.getLongFramePosition();
                audioFramesWritten = 0;
                audioClockReady = true;
            }
            int offset = 0;
            while (offset < pcm.length) {
                if (generation != eventGeneration) return;
                while (!closed.get() && generation == eventGeneration) {
                    if (requestedState != appliedState) applyRequestedState();
                    if (requestedState == State.PLAYING) break;
                    waitForStateChange();
                }
                if (closed.get() || generation != eventGeneration) return;
                int count = Math.min(4096, pcm.length - offset);
                int written = audioLine.write(pcm, offset, count);
                if (written <= 0) {
                    throw new IllegalStateException("Java Sound did not accept PCM audio data");
                }
                offset += written;
                audioFramesWritten += written / 4;
            }
        }

        private void waitForAudioToFinish() throws InterruptedException {
            while (!closed.get() && audioClockReady &&
                    audioLine.getLongFramePosition() - audioClockBaseFrame <
                            audioFramesWritten) {
                if (requestedState != appliedState) applyRequestedState();
                if (requestedState == State.STOPPED) return;
                if (requestedState == State.PAUSED) {
                    waitForStateChange();
                } else {
                    Thread.sleep(5);
                }
            }
        }

        private void waitForStateChange() {
            synchronized (stateLock) {
                if (!closed.get() && requestedState != State.PLAYING) {
                    try {
                        stateLock.wait();
                    } catch (InterruptedException exception) {
                        Thread.currentThread().interrupt();
                        closed.set(true);
                    }
                }
            }
        }

        private long currentClockUs() {
            if (audioClockReady) {
                long playedFrames = audioLine.getLongFramePosition() - audioClockBaseFrame;
                return audioClockBasePtsUs + playedFrames * 1_000_000L / AUDIO_RATE;
            }
            if (requestedState != State.PLAYING) return fallbackClockBasePtsUs;
            return fallbackClockBasePtsUs +
                    (System.nanoTime() - fallbackClockBaseNanos) / 1_000L;
        }

        private void resetAudioClock() {
            audioClockReady = false;
            audioClockBasePtsUs = 0;
            audioClockBaseFrame = audioLine.getLongFramePosition();
            audioFramesWritten = 0;
            fallbackClockBasePtsUs = 0;
            fallbackClockBaseNanos = System.nanoTime();
        }

        private String nativeError(Pointer handle) {
            byte[] buffer = new byte[1024];
            int length = NATIVE.fmp_get_error(handle, buffer, buffer.length);
            if (length < 0) return "Unknown native FMP error";
            return new String(buffer, 0, length, StandardCharsets.UTF_8);
        }

        @Override
        public void close() {
            if (!closed.compareAndSet(false, true)) return;
            videoTimer.stop();
            audioLine.stop();
            audioLine.flush();
            synchronized (stateLock) {
                stateLock.notifyAll();
            }
            worker.interrupt();
            try {
                worker.join();
            } catch (InterruptedException exception) {
                Thread.currentThread().interrupt();
            }
        }
    }

    private FmpSwingPlayer() {}

    public static void main(String[] args) {
        if (args.length < 1 || args.length > 2) {
            System.err.println(
                    "Usage: FmpSwingPlayer <media-file> [ASS/SSA-subtitle-file]");
            System.exit(2);
        }
        final String selectedMediaPath = args[0];
        final String selectedSubtitlePath = args.length == 2 ? args[1] : null;
        SwingUtilities.invokeLater(() ->
                createWindow(selectedMediaPath, selectedSubtitlePath));
    }

    private static void createWindow(String mediaPath, String subtitlePath) {
        VideoPanel panel = new VideoPanel();
        PlaybackController controller;
        try {
            controller = new PlaybackController(mediaPath, subtitlePath, panel);
        } catch (Exception exception) {
            JOptionPane.showMessageDialog(null, exception.getMessage(),
                    "Unable to start FMP", JOptionPane.ERROR_MESSAGE);
            return;
        }

        JButton play = new JButton("Play");
        JButton pause = new JButton("Pause");
        JButton stop = new JButton("Stop");
        play.addActionListener(event -> controller.play());
        pause.addActionListener(event -> controller.pause());
        stop.addActionListener(event -> controller.stop());

        JPanel controls = new JPanel();
        controls.add(play);
        controls.add(pause);
        controls.add(stop);

        JFrame window = new JFrame(
                "FMP Swing Player — " + controller.sourceVideoProfile);
        window.setLayout(new BorderLayout());
        window.add(panel, BorderLayout.CENTER);
        window.add(controls, BorderLayout.SOUTH);
        window.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        window.addWindowListener(new java.awt.event.WindowAdapter() {
            @Override
            public void windowClosed(java.awt.event.WindowEvent event) {
                controller.close();
            }
        });
        window.pack();
        window.setLocationRelativeTo(null);
        window.setVisible(true);
    }
}
