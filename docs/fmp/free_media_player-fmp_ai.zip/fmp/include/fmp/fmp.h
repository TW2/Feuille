#ifndef FMP_FMP_H
#define FMP_FMP_H

#include <stdint.h>

#if defined(_WIN32)
#if defined(FMP_BUILDING_LIBRARY)
#define FMP_API __declspec(dllexport)
#else
#define FMP_API __declspec(dllimport)
#endif
#else
#define FMP_API __attribute__((visibility("default")))
#endif

#ifdef __cplusplus
extern "C" {
#endif

typedef struct FmpPlayer FmpPlayer;

typedef enum FmpEventType {
    FMP_EVENT_NONE = 0,
    FMP_EVENT_VIDEO = 1,
    FMP_EVENT_AUDIO = 2
} FmpEventType;

typedef enum FmpNextResult {
    FMP_NEXT_ERROR = -1,
    FMP_NEXT_EOF = 0,
    FMP_NEXT_EVENT = 1,
    FMP_NEXT_PAUSED = 2
} FmpNextResult;

typedef enum FmpVideoProfile {
    FMP_VIDEO_PROFILE_OTHER = 0,
    FMP_VIDEO_PROFILE_NTSC_TELECINE = 1,
    FMP_VIDEO_PROFILE_NTSC_FILM = 2,
    FMP_VIDEO_PROFILE_PAL_25 = 3
} FmpVideoProfile;

typedef struct FmpEvent {
    FmpEventType type;
    int64_t pts_us;
    int64_t duration_us;

    /* Valid until the next fmp_next() or fmp_close() call. */
    const uint8_t *data;
    int32_t data_size;

    /* Video is packed RGBA, top row first. */
    int32_t width;
    int32_t height;
    int32_t stride;

    /* Audio is interleaved signed 16-bit little-endian PCM. */
    int32_t sample_rate;
    int32_t channels;
} FmpEvent;

typedef struct FmpScreenshot {
    int64_t pts_us;
    uint8_t *data;
    int32_t data_size;
    int32_t width;
    int32_t height;
    int32_t stride;
} FmpScreenshot;

typedef enum FmpScreenshotBackground {
    FMP_SCREENSHOT_BACKGROUND_VIDEO = 0,
    FMP_SCREENSHOT_BACKGROUND_CHECKERBOARD = 1
} FmpScreenshotBackground;

typedef struct FmpScreenshotOptions {
    FmpScreenshotBackground background;
    int32_t width;
    int32_t height;
    int32_t square_size;
    uint8_t color1_rgba[4];
    uint8_t color2_rgba[4];
} FmpScreenshotOptions;

/*
 * Opens a media file. Returns 0 on success and -1 on failure.
 * Only the first video and audio streams are decoded.
 */
FMP_API int fmp_open(const char *path, FmpPlayer **out_player);

/*
 * Gets the selected video's effective presentation rate as a
 * numerator/denominator pair. This applies the same NTSC/PAL normalization as
 * fmp_get_video_profile(). Returns 0 on success, or -1 if no usable rate is
 * available.
 */
FMP_API int fmp_get_video_frame_rate(FmpPlayer *player, int32_t *numerator,
                                     int32_t *denominator);

/*
 * Reports the detected source profile and effective frame rate. Telecine is
 * detected from sampled decoded repeat-field metadata, with the stream's
 * interlaced field order as a fallback signal. Rates are normalized to
 * 30000/1001 for NTSC telecine, 24000/1001 for NTSC film, and 25/1 for PAL
 * 25 fps; other rates retain FFmpeg's estimate.
 */
FMP_API int fmp_get_video_profile(FmpPlayer *player, int32_t *profile,
                                  int32_t *numerator, int32_t *denominator);

/*
 * Loads an external ASS/SSA subtitle file, replacing any embedded subtitle
 * track. The loaded track is composited onto subsequent video events.
 * Embedded ASS/SSA tracks are loaded automatically when present.
 */
FMP_API int fmp_load_subtitles(FmpPlayer *player, const char *path);

/*
 * Demuxes media while native audio, video, and subtitle workers process their
 * respective streams. Audio and video are separate events and need not share
 * timestamps. Returns events in presentation-timestamp order when both streams
 * are ready; if one stream is delayed, a ready event is returned after a
 * bounded lookahead. Also returns FMP_NEXT_EOF at end-of-file,
 * FMP_NEXT_PAUSED while stopped or paused, and FMP_NEXT_ERROR on error. Call
 * this function serially for a given player handle; audio/video/subtitle work
 * runs on separate native threads.
 */
FMP_API int fmp_next(FmpPlayer *player, FmpEvent *event);

/*
 * Playback controls affect event delivery only; Java remains responsible for
 * presentation and for pausing audio it has already queued.
 */
FMP_API int fmp_play(FmpPlayer *player);
FMP_API int fmp_pause(FmpPlayer *player);
FMP_API int fmp_stop(FmpPlayer *player);

/*
 * Captures the video frame at or immediately before position_us without
 * changing playback state. If position_us is before the first frame, the
 * first frame is returned; if it is beyond the end, the last frame is
 * returned. An optional ASS/SSA subtitle file is composited onto the image.
 * Returns 0 on success and -1 on error. Free successful results with
 * fmp_screenshot_free().
 */
FMP_API int fmp_screenshot(const char *media_path, int64_t position_us,
                           const char *subtitle_path, FmpScreenshot *screenshot);

/*
 * Captures a screenshot using the requested background. A null options pointer
 * selects the video behavior of fmp_screenshot(). For a checkerboard,
 * media_path may be null; width, height, square_size, and both RGBA colors in
 * options are required. If subtitle_path is non-null, its external ASS/SSA
 * subtitles are composited at position_us, which must be non-negative.
 * Video-only arguments are ignored in checkerboard mode. Returns 0 on success
 * and -1 on error.
 */
FMP_API int fmp_screenshot_with_options(
    const char *media_path, int64_t position_us, const char *subtitle_path,
    const FmpScreenshotOptions *options, FmpScreenshot *screenshot);

/* Releases pixel data returned by fmp_screenshot() and clears the structure. */
FMP_API void fmp_screenshot_free(FmpScreenshot *screenshot);

/* Seeks to a position in microseconds from the beginning of the media. */
FMP_API int fmp_seek(FmpPlayer *player, int64_t position_us);

/*
 * Copies the most recent error message into buffer, including its NUL.
 * Pass a null player to retrieve the latest thread-local error from
 * fmp_open() or fmp_screenshot().
 */
FMP_API int fmp_get_error(FmpPlayer *player, char *buffer, int32_t buffer_size);

FMP_API void fmp_close(FmpPlayer *player);

#ifdef __cplusplus
}
#endif

#endif
