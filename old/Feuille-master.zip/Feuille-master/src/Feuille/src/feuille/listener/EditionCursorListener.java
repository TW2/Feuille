/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package feuille.listener;

import java.util.EventListener;

/**
 *
 * @author util2
 */
public abstract class EditionCursorListener implements EventListener, EditionCursor {
    //Nothing needed cause abstract (just implements EventListener)
}
