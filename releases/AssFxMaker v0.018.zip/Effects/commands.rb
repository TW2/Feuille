require 'java'

# FORMAT : pluginname, displayname, function, version, description, author, help, type
# TYPE : function, macro, shortcut, command
Java::assfxmaker.lib.scripting.ScriptPlugin.addButton("UGPlugin","User guide","userguide", "1.0", "Open the user guide.", "Chien-Rouge", "No help.","shortcut")

def userguide
  mainpath = Java::assfxmaker.lib.scripting.ScriptPlugin.getDocsPath()+"AssFxMaker Guide.pdf"
  # system(mainpath)
  Java::assfxmaker.lib.scripting.ScriptPlugin.openFile(mainpath)
end