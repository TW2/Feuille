#!/usr/bin/env jython

from assfxmaker.lib.scripting import ScriptPlugin

# Register the function in the main program.
ScriptPlugin.addTheme("5B5B5B", "999999", "DeepGray")

# Register the function in the main program.
ScriptPlugin.addTheme("FFE500", "999999", "Gray with yellow")

# Register the function in the main program.
ScriptPlugin.addTheme("FF02AA", "999999", "Gray with purple")

# Register the function in the main program.
ScriptPlugin.addTheme("00FFB2", "999999", "Gray with azure")

# Register the function in the main program.
ScriptPlugin.addTheme("FFE500", "FFE500", "Full yellow")