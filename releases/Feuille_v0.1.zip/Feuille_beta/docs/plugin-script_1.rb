require 'java'

# FORMAT : pluginname, displayname, function, version, description, author, help, type
# TYPE : function, macro, shortcut, command
Java::smallboxforfansub.scripting.ScriptPlugin.addButton("UGPlugin","User guide","userguide", "1.0", "Open the user guide.", "Chien-Rouge", "No help.","shortcut")

def userguide
  mainpath = Java::smallboxforfansub.scripting.ScriptPlugin.getDocsPath()+"Feuille Guide.pdf"
  # system(mainpath)
  Java::smallboxforfansub.scripting.ScriptPlugin.openFile(mainpath)
end