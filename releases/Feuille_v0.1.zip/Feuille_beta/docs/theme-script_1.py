#!/usr/bin/env jython

from smallboxforfansub.scripting import ScriptPlugin

# Add the themes to the main program.
ScriptPlugin.addTheme("5B5B5B", "999999", "DeepGray")
ScriptPlugin.addTheme("FFE500", "999999", "Gray with yellow")
ScriptPlugin.addTheme("FF02AA", "999999", "Gray with purple")
ScriptPlugin.addTheme("00FFB2", "999999", "Gray with azure")
ScriptPlugin.addTheme("FFE500", "FFE500", "Full yellow")