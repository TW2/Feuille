/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package smallboxforfansub;

/**
 *
 * @author The Wingate 2940
 */
public class SmallBoxForFansub {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        if(args.length==0){
            MainFrame mf = new MainFrame();
            mf.setVisible(true);
        }else{
            // TODO Command line
        }
    }
}
